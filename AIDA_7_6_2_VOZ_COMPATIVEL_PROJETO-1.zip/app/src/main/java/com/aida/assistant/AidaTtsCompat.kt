package com.aida.assistant

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.os.Bundle
import android.speech.tts.TextToSpeech
import java.util.Locale

/**
 * Camada de compatibilidade de voz da AIDA.
 *
 * Evita dois problemas comuns em aparelhos Samsung/Android Go:
 * 1) o motor aceita pt-BR, mas escolhe uma voz de rede sem dados locais;
 * 2) a fala é enviada para um uso de áudio pouco audível no aparelho.
 */
object AidaTtsCompat {
    data class ConfigResult(
        val ok: Boolean,
        val localeTag: String = "",
        val voiceName: String = "",
        val reason: String = ""
    )

    fun configure(tts: TextToSpeech): ConfigResult {
        val candidates = linkedSetOf(
            Locale("pt", "BR"),
            Locale("pt"),
            Locale.getDefault()
        )

        var selected: Locale? = null
        var lastReason = "Nenhum idioma de voz compatível foi encontrado."

        for (locale in candidates) {
            val available = runCatching { tts.isLanguageAvailable(locale) }
                .getOrDefault(TextToSpeech.LANG_NOT_SUPPORTED)
            if (available < TextToSpeech.LANG_AVAILABLE) {
                lastReason = "Idioma ${locale.toLanguageTag()} sem dados instalados."
                continue
            }

            val set = runCatching { tts.setLanguage(locale) }
                .getOrDefault(TextToSpeech.ERROR)
            if (set >= TextToSpeech.LANG_AVAILABLE) {
                selected = locale
                break
            }
            lastReason = "O motor recusou o idioma ${locale.toLanguageTag()}."
        }

        if (selected == null) return ConfigResult(false, reason = lastReason)

        // Prefere voz local/offline. Alguns motores selecionam automaticamente uma
        // voz de rede e ficam mudos quando o pacote não está baixado.
        val voices = runCatching { tts.voices?.toList().orEmpty() }.getOrDefault(emptyList())
        val exactOffline = voices.firstOrNull {
            it.locale.language == selected.language &&
                it.locale.country.equals(selected.country, ignoreCase = true) &&
                !it.isNetworkConnectionRequired
        }
        val languageOffline = voices.firstOrNull {
            it.locale.language == selected.language && !it.isNetworkConnectionRequired
        }
        val exactAny = voices.firstOrNull {
            it.locale.language == selected.language &&
                it.locale.country.equals(selected.country, ignoreCase = true)
        }
        val languageAny = voices.firstOrNull { it.locale.language == selected.language }
        val chosen = exactOffline ?: languageOffline ?: exactAny ?: languageAny
        if (chosen != null) runCatching { tts.voice = chosen }

        // Voz da assistente deve sair pelo volume de mídia, que é o fluxo mais
        // previsível entre Samsung, Google TTS e Android Go.
        runCatching {
            tts.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
        }

        return ConfigResult(
            ok = true,
            localeTag = selected.toLanguageTag(),
            voiceName = chosen?.name.orEmpty()
        )
    }

    fun speakParams(): Bundle = Bundle().apply {
        putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f)
        putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, AudioManager.STREAM_MUSIC)
    }

    @Suppress("DEPRECATION")
    fun installedEngines(context: Context): List<String> {
        val intent = Intent(TextToSpeech.Engine.INTENT_ACTION_TTS_SERVICE)
        return context.packageManager
            .queryIntentServices(intent, PackageManager.MATCH_ALL)
            .mapNotNull { it.serviceInfo?.packageName }
            .distinct()
    }

    fun installVoiceDataIntent(): Intent = Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA)

    fun ttsSettingsIntent(): Intent = Intent("com.android.settings.TTS_SETTINGS")
}
