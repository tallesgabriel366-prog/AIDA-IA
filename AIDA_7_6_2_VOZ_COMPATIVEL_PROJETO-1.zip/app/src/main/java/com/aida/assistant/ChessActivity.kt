package com.aida.assistant

import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.SystemClock
import android.media.AudioAttributes
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

class ChessActivity : Activity() {
    private val engine = ChessEngine()
    private lateinit var boardView: ChessBoardView
    private lateinit var statusView: TextView
    private lateinit var ratingRow: LinearLayout
    private lateinit var teacherButton: Button

    private var selectedLevel = 0
    private var aiThinking = false
    private var teacherEnabled = true
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pendingSpeech: Pair<String, Boolean>? = null
    private var gameGeneration = 0L

    private val ratings = intArrayOf(400, 700, 1000, 1400, 1800, 2200)
    private val levelNames = arrayOf("Iniciante", "Básico", "Intermediário", "Avançado", "Especialista", "Mestre")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(3, 20, 16)
        window.navigationBarColor = Color.BLACK

        tts = TextToSpeech(this) { result ->
            if (result == TextToSpeech.SUCCESS) {
                val local = tts
                val config = local?.let { AidaTtsCompat.configure(it) }
                if (config?.ok == true) {
                    local.setSpeechRate(1.0f)
                    local.setPitch(1.0f)
                    ttsReady = true
                    pendingSpeech?.let { (text, flush) ->
                        pendingSpeech = null
                        speak(text, flush)
                    }
                } else {
                    ttsReady = false
                }
            }
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = verticalGradient(Color.rgb(2, 31, 24), Color.rgb(1, 14, 12))
        }

        root.addView(TextView(this).apply {
            text = "♟ AIDA • Professora de Xadrez"
            textSize = 21f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setShadowLayer(dp(8).toFloat(), 0f, 0f, Color.rgb(41, 196, 132))
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        root.addView(TextView(this).apply {
            text = "Partida guiada • voz ativa • dicas a cada lance"
            textSize = 12.5f
            setTextColor(Color.rgb(183, 229, 211))
            gravity = Gravity.CENTER
            setPadding(0, dp(3), 0, dp(6))
        })

        val ratingScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
        }
        ratingRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(2), dp(2), dp(2), dp(4))
        }
        ratingScroll.addView(ratingRow)
        root.addView(ratingScroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(52)))
        renderRatingButtons()

        statusView = TextView(this).apply {
            text = initialStatus()
            textSize = 13.5f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = rounded(Color.rgb(10, 58, 44), Color.rgb(69, 202, 145), 14)
        }
        root.addView(statusView, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(74)).apply {
            bottomMargin = dp(7)
        })

        boardView = ChessBoardView(this)
        root.addView(boardView, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        val row1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(7), 0, 0)
        }
        row1.addView(actionButton("💡 Dica") { showHint() }, tripleParams())
        row1.addView(actionButton("↶ Desfazer") { undoMove() }, tripleParams(dp(5)))
        row1.addView(actionButton("↻ Nova") { newGame() }, tripleParams(dp(5)))
        root.addView(row1)

        val row2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(5), 0, 0)
        }
        teacherButton = actionButton("🎓 Professora ON") { toggleTeacher() }
        row2.addView(teacherButton, tripleParams())
        row2.addView(actionButton("📘 Aula") { showLesson() }, tripleParams(dp(5)))
        row2.addView(actionButton("← Voltar") { finish() }, tripleParams(dp(5)))
        root.addView(row2)

        setContentView(root)
        root.alpha = 0.18f
        root.translationY = dp(18).toFloat()
        root.scaleX = 0.985f
        root.scaleY = 0.985f
        root.animate()
            .alpha(1f)
            .translationY(0f)
            .scaleX(1f)
            .scaleY(1f)
            .setDuration(240L)
            .start()
        statusView.postDelayed({
            speak("Modo professora de xadrez aberto. Você joga de brancas. Eu vou comentar suas jogadas e também as minhas.", flush = true)
        }, 350L)
    }

    private fun initialStatus(): String =
        "${levelNames[selectedLevel]} • rating ${ratings[selectedLevel]} • Professora ${if (teacherEnabled) "ON" else "OFF"}\nVocê joga de brancas. Toque em uma peça e depois na casa de destino."

    private fun renderRatingButtons() {
        ratingRow.removeAllViews()
        ratings.forEachIndexed { index, rating ->
            val selected = index == selectedLevel
            ratingRow.addView(Button(this).apply {
                text = "${levelNames[index]}\n$rating"
                textSize = 10.5f
                isAllCaps = false
                setTextColor(Color.WHITE)
                minWidth = dp(98)
                minHeight = 0
                setPadding(dp(7), 0, dp(7), 0)
                background = rounded(
                    if (selected) Color.rgb(31, 136, 94) else Color.rgb(8, 53, 39),
                    if (selected) Color.rgb(132, 255, 201) else Color.rgb(42, 132, 95),
                    14
                )
                alpha = if (selected) 1f else 0.82f
                setOnClickListener {
                    performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                    if (aiThinking || boardView.isAnimatingMove()) {
                        setStatus("Aguarde a jogada da AIDA antes de trocar o nível.")
                        return@setOnClickListener
                    }
                    selectedLevel = index
                    renderRatingButtons()
                    newGame()
                }
            }, LinearLayout.LayoutParams(dp(108), dp(46)).apply {
                if (index > 0) marginStart = dp(5)
            })
        }
    }

    private fun toggleTeacher() {
        teacherEnabled = !teacherEnabled
        teacherButton.text = if (teacherEnabled) "🎓 Professora ON" else "🔇 Professora OFF"
        teacherButton.alpha = if (teacherEnabled) 1f else 0.72f
        val text = if (teacherEnabled) {
            "Modo professora ativado. Vou falar e explicar durante a partida."
        } else {
            "Modo professora em silêncio. As dicas visuais continuam disponíveis."
        }
        setStatus(text, speakIt = true)
    }

    private fun newGame() {
        if (aiThinking || boardView.isAnimatingMove()) {
            setStatus("Aguarde a jogada atual terminar antes de reiniciar.")
            return
        }
        gameGeneration++
        tts?.stop()
        engine.reset()
        boardView.resetVisuals()
        setStatus(initialStatus(), speakIt = teacherEnabled)
    }

    private fun undoMove() {
        if (aiThinking || boardView.isAnimatingMove()) {
            setStatus("Aguarde a AIDA terminar a jogada para desfazer o turno.")
            return
        }
        if (!engine.canUndo()) {
            setStatus("Ainda não há lance para desfazer.")
            return
        }
        val undone = engine.undoLastTurn()
        boardView.resetVisuals()
        val text = if (undone >= 2) {
            "Último turno desfeito. Voltamos para antes da sua jogada."
        } else {
            "Último lance desfeito."
        }
        setStatus("$text\n${engine.teacherTip()}", speakIt = teacherEnabled)
    }

    private fun showHint() {
        if (aiThinking || boardView.isAnimatingMove()) {
            setStatus("Aguarde a jogada da AIDA antes de pedir uma dica.")
            return
        }
        if (!engine.whiteTurn) {
            setStatus("AIDA ainda está jogando. Aguarde um instante.")
            return
        }
        val result = engine.gameResult()
        if (result.ended) {
            announceResult(result)
            return
        }
        val hint = engine.bestHintForWhite()
        if (hint == null) {
            setStatus(result.message.ifBlank { "Não há jogadas legais." }, speakIt = true)
            return
        }
        val text = "Dica da professora: considere ${engine.moveToText(hint)}. ${engine.teacherTip()}"
        boardView.highlightHint(hint)
        setStatus(text, speakIt = true)
    }

    private fun showLesson() {
        val message = """
            COMO PENSAR EM CADA JOGADA
            1. Meu rei está seguro?
            2. Tenho algum xeque forte?
            3. Posso capturar algo sem perder material?
            4. O adversário está ameaçando alguma peça?
            5. Posso desenvolver uma peça ou melhorar minha posição?

            ABERTURA
            • Dispute o centro com peões e peças.
            • Desenvolva cavalos e bispos.
            • Faça o roque cedo quando for seguro.
            • Evite mover a dama cedo sem necessidade.

            TÁTICAS IMPORTANTES
            • Garfo: uma peça ataca duas ao mesmo tempo.
            • Cravada: uma peça não pode sair sem perder algo mais importante.
            • Ataque descoberto: mover uma peça libera o ataque de outra.
            • Raio-X: pressão através de uma peça alinhada.

            REGRAS ATIVAS NESTE TABULEIRO
            • Roque pequeno e grande.
            • En passant.
            • Promoção automática para dama.
            • Xeque, xeque-mate e afogamento.
            • Regra dos 50 lances e material insuficiente.

            VALORES BÁSICOS
            Dama 9 • Torre 5 • Bispo 3 • Cavalo 3 • Peão 1
        """.trimIndent()

        AlertDialog.Builder(this)
            .setTitle("🎓 Aula de xadrez da AIDA")
            .setMessage(message)
            .setNeutralButton("🔊 Ouvir resumo") { _, _ ->
                speak("Antes de cada jogada, confira a segurança do rei, procure xeques, capturas e ameaças. Na abertura, controle o centro, desenvolva cavalos e bispos e faça o roque quando estiver seguro.", flush = true)
            }
            .setPositiveButton("Entendi", null)
            .show()
    }

    private fun afterHumanMove(move: ChessEngine.Move, moveText: String, coachText: String) {
        val result = engine.gameResult()
        if (teacherEnabled) {
            val checkText = if (engine.isCurrentSideInCheck()) " Xeque." else ""
            speak("Você jogou $moveText.$checkText $coachText", flush = false)
        }

        if (result.ended) {
            announceResult(result)
            return
        }

        val check = if (engine.isCurrentSideInCheck()) " Xeque!" else ""
        setStatus("Você jogou $moveText.$check\nAIDA está analisando a posição…")
        aiThinking = true
        val levelForMove = selectedLevel
        val generation = ++gameGeneration
        val start = SystemClock.elapsedRealtime()

        Thread {
            val aiMove = runCatching { engine.chooseAiMove(levelForMove) }.getOrNull()
            val minThink = 950L + levelForMove * 120L + Random.nextLong(250L, 650L)
            val elapsed = SystemClock.elapsedRealtime() - start
            if (elapsed < minThink) Thread.sleep(minThink - elapsed)

            runOnUiThread {
                if (isFinishing || isDestroyed || generation != gameGeneration) return@runOnUiThread
                if (aiMove == null) {
                    aiThinking = false
                    val end = engine.gameResult()
                    if (end.ended) announceResult(end)
                    else setStatus("AIDA não encontrou uma jogada legal.", speakIt = true)
                    return@runOnUiThread
                }

                val aiText = engine.moveToText(aiMove)
                val movingPiece = engine.pieceAt(aiMove.fromRow, aiMove.fromCol)
                if (!engine.makeMove(aiMove)) {
                    aiThinking = false
                    setStatus("AIDA encontrou um lance inválido e cancelou a jogada. Tente novamente.", speakIt = true)
                    return@runOnUiThread
                }

                boardView.clearSelection()
                boardView.animateMove(aiMove, movingPiece, 520L) {
                    if (generation != gameGeneration) return@animateMove
                    aiThinking = false
                    val end = engine.gameResult()
                    if (end.ended) {
                        if (teacherEnabled) speak("Eu joguei $aiText.", flush = false)
                        announceResult(end)
                    } else {
                        val checkText = if (engine.isCurrentSideInCheck()) " Seu rei está em xeque." else ""
                        val tip = engine.teacherTip()
                        setStatus("AIDA jogou $aiText.$checkText\n$tip")
                        if (teacherEnabled) {
                            speak("Eu joguei $aiText.$checkText $tip", flush = false)
                        }
                        if (engine.isCurrentSideInCheck()) boardView.flashCheck()
                    }
                }
            }
        }.start()
    }

    private fun announceResult(result: ChessEngine.GameResult) {
        aiThinking = false
        boardView.clearSelection()
        val won = result.winner == ChessEngine.Winner.WHITE
        val lost = result.winner == ChessEngine.Winner.BLACK
        boardView.startResultAnimation(result.winner)
        statusView.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)

        val prefix = when {
            result.checkmate && won -> "🏆 XEQUE-MATE • VOCÊ VENCEU"
            result.checkmate && lost -> "♚ XEQUE-MATE • AIDA VENCEU"
            else -> "🤝 PARTIDA ENCERRADA"
        }
        setStatus("$prefix\n${result.message}")

        val spoken = when {
            result.checkmate && won -> "Xeque-mate! Parabéns, você venceu. Muito boa partida."
            result.checkmate && lost -> "Xeque-mate. Eu venci esta partida. Vamos jogar de novo e eu posso explicar onde a posição virou."
            else -> result.message
        }
        speak(spoken, flush = true)
    }

    private fun setStatus(text: String, speakIt: Boolean = false) {
        statusView.text = text
        statusView.animate().cancel()
        statusView.alpha = 0.72f
        statusView.scaleX = 0.985f
        statusView.scaleY = 0.985f
        statusView.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180L).start()
        if (speakIt) speak(text, flush = true)
    }

    private fun speak(text: String, flush: Boolean = false) {
        if (!ttsReady) {
            pendingSpeech = text to flush
            return
        }
        val clean = text
            .replace("•", ".")
            .replace("…", ".")
            .replace("🏆", "")
            .replace("♚", "")
            .replace("🤝", "")
            .replace("↻", "")
            .replace("↶", "")
            .replace(Regex("\\s+"), " ")
            .trim()
        val queueMode = if (flush) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
        tts?.speak(clean, queueMode, AidaTtsCompat.speakParams(), "AIDA_CHESS_${System.nanoTime()}")
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    override fun onDestroy() {
        gameGeneration++
        tts?.stop()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }

    private fun actionButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 10.8f
        isAllCaps = false
        setTextColor(Color.WHITE)
        minHeight = 0
        setPadding(dp(3), 0, dp(3), 0)
        background = rounded(Color.rgb(9, 70, 51), Color.rgb(47, 166, 117), 13)
        setOnClickListener {
            performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            animate().cancel()
            scaleX = 0.96f
            scaleY = 0.96f
            animate().scaleX(1f).scaleY(1f).setDuration(120L).start()
            action()
        }
    }

    private fun tripleParams(startMargin: Int = 0) = LinearLayout.LayoutParams(0, dp(44), 1f).apply {
        marginStart = startMargin
    }

    private fun rounded(fill: Int, stroke: Int, radiusDp: Int) = GradientDrawable().apply {
        cornerRadius = dp(radiusDp).toFloat()
        setColor(fill)
        setStroke(dp(1), stroke)
    }

    private fun verticalGradient(top: Int, bottom: Int) = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM,
        intArrayOf(top, bottom)
    )

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    inner class ChessBoardView(context: android.content.Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var selectedRow = -1
        private var selectedCol = -1
        private var legalTargets: List<ChessEngine.Move> = emptyList()
        private var hintedMove: ChessEngine.Move? = null
        private var lastMove: ChessEngine.Move? = null

        private var moveAnimator: ValueAnimator? = null
        private var animatedMove: ChessEngine.Move? = null
        private var animatedPiece: Char = ' '
        private var moveProgress = 1f
        private var checkFlashStarted = 0L

        private var resultAnimator: ValueAnimator? = null
        private var resultProgress = 0f
        private var resultWinner = ChessEngine.Winner.NONE

        init {
            isClickable = true
            isFocusable = true
            contentDescription = "Tabuleiro de xadrez. Você joga de brancas."
            setLayerType(LAYER_TYPE_SOFTWARE, null)
        }

        override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
            val available = MeasureSpec.getSize(widthMeasureSpec)
            val size = if (available > 0) available else dp(330)
            setMeasuredDimension(size, size)
        }

        fun isAnimatingMove(): Boolean = moveAnimator?.isRunning == true

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val size = width.coerceAtMost(height).toFloat()
            val cell = size / 8f
            val light = Color.rgb(235, 224, 198)
            val dark = Color.rgb(67, 126, 89)
            val now = SystemClock.elapsedRealtime()

            paint.style = Paint.Style.FILL
            paint.shader = RadialGradient(size / 2f, size / 2f, size * 0.7f,
                intArrayOf(Color.rgb(18, 72, 54), Color.rgb(3, 29, 23)), null, Shader.TileMode.CLAMP)
            canvas.drawRoundRect(0f, 0f, size, size, dp(10).toFloat(), dp(10).toFloat(), paint)
            paint.shader = null

            val checkedWhite = engine.isKingInCheck(true)
            val checkedBlack = engine.isKingInCheck(false)
            val checkSquare = when {
                checkedWhite -> engine.kingSquare(true)
                checkedBlack -> engine.kingSquare(false)
                else -> null
            }

            for (r in 0..7) for (c in 0..7) {
                paint.style = Paint.Style.FILL
                paint.color = if ((r + c) % 2 == 0) light else dark
                canvas.drawRect(c * cell, r * cell, (c + 1) * cell, (r + 1) * cell, paint)

                val recent = lastMove
                if (recent != null && ((recent.fromRow == r && recent.fromCol == c) || (recent.toRow == r && recent.toCol == c))) {
                    paint.color = Color.argb(105, 255, 225, 72)
                    canvas.drawRect(c * cell, r * cell, (c + 1) * cell, (r + 1) * cell, paint)
                }

                if (r == selectedRow && c == selectedCol) {
                    paint.color = Color.argb(155, 255, 193, 7)
                    canvas.drawRect(c * cell, r * cell, (c + 1) * cell, (r + 1) * cell, paint)
                }

                val targetMove = legalTargets.firstOrNull { it.toRow == r && it.toCol == c }
                if (targetMove != null) {
                    val occupied = engine.pieceAt(r, c) != ' '
                    if (occupied || targetMove.isEnPassant) {
                        paint.style = Paint.Style.STROKE
                        paint.strokeWidth = cell * 0.08f
                        paint.color = Color.argb(175, 130, 20, 20)
                        canvas.drawCircle(c * cell + cell / 2, r * cell + cell / 2, cell * 0.39f, paint)
                        paint.style = Paint.Style.FILL
                    } else {
                        paint.color = Color.argb(155, 21, 38, 30)
                        canvas.drawCircle(c * cell + cell / 2, r * cell + cell / 2, cell * 0.105f, paint)
                    }
                }

                val hint = hintedMove
                if (hint != null && ((hint.fromRow == r && hint.fromCol == c) || (hint.toRow == r && hint.toCol == c))) {
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = dp(3).toFloat()
                    paint.color = Color.rgb(255, 193, 7)
                    canvas.drawRect(c * cell + dp(2), r * cell + dp(2), (c + 1) * cell - dp(2), (r + 1) * cell - dp(2), paint)
                    paint.style = Paint.Style.FILL
                }

                if (checkSquare != null && checkSquare.first == r && checkSquare.second == c) {
                    val pulse = ((sin((now - checkFlashStarted).coerceAtLeast(0L) / 90.0) + 1.0) / 2.0).toFloat()
                    paint.color = Color.argb((105 + 90 * pulse).toInt(), 225, 30, 54)
                    canvas.drawRect(c * cell, r * cell, (c + 1) * cell, (r + 1) * cell, paint)
                }

                val anim = animatedMove
                val hideDestination = anim != null && moveProgress < 0.999f && anim.toRow == r && anim.toCol == c
                if (!hideDestination) {
                    drawPiece(canvas, engine.pieceAt(r, c), c * cell + cell / 2, r * cell + cell * 0.75f, cell)
                }

                paint.textSize = cell * 0.16f
                paint.typeface = Typeface.DEFAULT_BOLD
                paint.clearShadowLayer()
                if (c == 0) {
                    paint.textAlign = Paint.Align.LEFT
                    paint.color = if ((r + c) % 2 == 0) dark else light
                    canvas.drawText((8 - r).toString(), c * cell + dp(2), r * cell + cell * 0.18f, paint)
                }
                if (r == 7) {
                    paint.textAlign = Paint.Align.RIGHT
                    paint.color = if ((r + c) % 2 == 0) dark else light
                    canvas.drawText(('a'.code + c).toChar().toString(), (c + 1) * cell - dp(2), (r + 1) * cell - dp(2), paint)
                }
            }

            drawAnimatedPiece(canvas, cell)
            drawThinkingIndicator(canvas, size, now)
            drawResultOverlay(canvas, size, now)

            if (isAnimatingMove() || aiThinking || resultAnimator?.isRunning == true || (resultWinner == ChessEngine.Winner.NONE && engine.isCurrentSideInCheck())) {
                postInvalidateOnAnimation()
            }
        }

        private fun drawAnimatedPiece(canvas: Canvas, cell: Float) {
            val move = animatedMove ?: return
            if (moveProgress >= 1f) return
            val sx = move.fromCol * cell + cell / 2f
            val sy = move.fromRow * cell + cell * 0.75f
            val ex = move.toCol * cell + cell / 2f
            val ey = move.toRow * cell + cell * 0.75f
            val x = sx + (ex - sx) * moveProgress
            val y = sy + (ey - sy) * moveProgress
            val lift = sin(moveProgress * PI).toFloat() * cell * 0.08f
            drawPiece(canvas, animatedPiece, x, y - lift, cell * (1f + 0.08f * sin(moveProgress * PI).toFloat()))
        }

        private fun drawThinkingIndicator(canvas: Canvas, size: Float, now: Long) {
            if (!aiThinking || resultWinner != ChessEngine.Winner.NONE) return
            val phase = (now % 1200L) / 1200f
            paint.style = Paint.Style.FILL
            paint.color = Color.argb(165, 3, 28, 21)
            canvas.drawRoundRect(size - dp(78), dp(8).toFloat(), size - dp(8), dp(34).toFloat(), dp(13).toFloat(), dp(13).toFloat(), paint)
            paint.textAlign = Paint.Align.LEFT
            paint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            paint.textSize = dp(9).toFloat()
            paint.color = Color.rgb(205, 240, 225)
            canvas.drawText("AIDA", size - dp(70), dp(25).toFloat(), paint)
            repeat(3) { i ->
                val wave = ((sin((phase * 2f * PI + i * 1.5f).toFloat()) + 1f) / 2f)
                paint.color = Color.argb((90 + 165 * wave).toInt(), 114, 255, 190)
                canvas.drawCircle(size - dp(31 - i * 8), dp(21).toFloat(), dp(2).toFloat() + wave, paint)
            }
        }

        private fun drawResultOverlay(canvas: Canvas, size: Float, now: Long) {
            if (resultWinner == ChessEngine.Winner.NONE || resultProgress <= 0f) return
            val p = resultProgress.coerceIn(0f, 1f)
            val alpha = (150 * p).toInt().coerceIn(0, 170)
            val won = resultWinner == ChessEngine.Winner.WHITE
            val lost = resultWinner == ChessEngine.Winner.BLACK

            paint.style = Paint.Style.FILL
            paint.color = when {
                won -> Color.argb(alpha, 10, 92, 48)
                lost -> Color.argb(alpha, 110, 16, 32)
                else -> Color.argb(alpha, 35, 42, 52)
            }
            canvas.drawRect(0f, 0f, size, size, paint)

            if (won) {
                repeat(28) { i ->
                    val phase = i * 0.77f
                    val x = ((i * 47) % 100) / 100f * size
                    val y = (((now / 10L + i * 31L) % 1300L) / 1300f) * size
                    val r = 2.5f + (i % 4)
                    paint.color = Color.argb((120 + 100 * sin(phase).coerceAtLeast(0f)).toInt(),
                        if (i % 3 == 0) 255 else 120,
                        if (i % 3 == 1) 230 else 180,
                        if (i % 3 == 2) 255 else 100)
                    canvas.drawCircle(x, y, r, paint)
                }
            }

            paint.textAlign = Paint.Align.CENTER
            paint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            paint.setShadowLayer(dp(10).toFloat(), 0f, 0f, Color.BLACK)
            paint.textSize = size * 0.115f
            paint.color = Color.WHITE
            val title = when {
                won -> "VITÓRIA!"
                lost -> "XEQUE-MATE"
                else -> "EMPATE"
            }
            val bounce = 1f + 0.05f * sin(p * PI * 3).toFloat()
            canvas.save()
            canvas.scale(bounce, bounce, size / 2f, size / 2f)
            canvas.drawText(title, size / 2f, size * 0.49f, paint)
            paint.textSize = size * 0.045f
            paint.color = Color.rgb(225, 244, 236)
            canvas.drawText(if (won) "Parabéns!" else if (lost) "Tente novamente" else "Boa partida", size / 2f, size * 0.56f, paint)
            canvas.restore()
            paint.clearShadowLayer()
        }

        private fun drawPiece(canvas: Canvas, piece: Char, x: Float, y: Float, cell: Float) {
            if (piece == ' ') return
            paint.style = Paint.Style.FILL
            paint.textAlign = Paint.Align.CENTER
            paint.textSize = cell * 0.72f
            paint.typeface = Typeface.DEFAULT_BOLD
            if (piece.isUpperCase()) {
                paint.color = Color.WHITE
                paint.setShadowLayer(dp(2).toFloat(), 0f, dp(1).toFloat(), Color.BLACK)
            } else {
                paint.color = Color.rgb(18, 18, 18)
                paint.setShadowLayer(dp(1).toFloat(), 0f, dp(1).toFloat(), Color.WHITE)
            }
            canvas.drawText(pieceGlyph(piece), x, y, paint)
            paint.clearShadowLayer()
        }

        private fun pieceGlyph(ch: Char): String = when (ch) {
            'K' -> "♔"; 'Q' -> "♕"; 'R' -> "♖"; 'B' -> "♗"; 'N' -> "♘"; 'P' -> "♙"
            'k' -> "♚"; 'q' -> "♛"; 'r' -> "♜"; 'b' -> "♝"; 'n' -> "♞"; 'p' -> "♟"
            else -> ""
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (event.action != MotionEvent.ACTION_UP) return true
            performClick()

            if (resultWinner != ChessEngine.Winner.NONE) {
                setStatus("A partida terminou. Toque em Nova para jogar outra ou Desfazer para voltar.")
                return true
            }
            if (isAnimatingMove() || aiThinking || !engine.whiteTurn) {
                setStatus("AIDA está pensando. Aguarde a jogada dela.")
                return true
            }

            val cell = width.coerceAtMost(height) / 8f
            val col = (event.x / cell).toInt()
            val row = (event.y / cell).toInt()
            if (row !in 0..7 || col !in 0..7) return true
            hintedMove = null

            if (selectedRow < 0) {
                selectSquare(row, col)
                return true
            }

            val chosen = legalTargets.firstOrNull { it.toRow == row && it.toCol == col }
            if (chosen != null) {
                val moveText = engine.moveToText(chosen)
                val coachText = engine.explainWhiteMove(chosen)
                val movingPiece = engine.pieceAt(chosen.fromRow, chosen.fromCol)
                if (engine.makeMove(chosen)) {
                    performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                    clearSelection()
                    setStatus("Você jogou $moveText.\nAIDA vai responder em instantes…")
                    animateMove(chosen, movingPiece, 260L) {
                        if (engine.isCurrentSideInCheck()) flashCheck()
                        afterHumanMove(chosen, moveText, coachText)
                    }
                }
                return true
            }

            if (engine.pieceAt(row, col).isUpperCase()) {
                selectSquare(row, col)
            } else {
                clearSelection()
                setStatus("Essa casa não é um destino legal. Escolha outra peça branca.")
                invalidate()
            }
            return true
        }

        override fun performClick(): Boolean {
            super.performClick()
            return true
        }

        private fun selectSquare(row: Int, col: Int) {
            val piece = engine.pieceAt(row, col)
            if (!piece.isUpperCase()) {
                setStatus("Escolha uma peça branca.")
                return
            }
            val moves = engine.legalMovesForSquare(row, col)
            if (moves.isEmpty()) {
                setStatus("Essa peça não possui movimentos legais agora.")
                clearSelection()
            } else {
                selectedRow = row
                selectedCol = col
                legalTargets = moves
                setStatus("${engine.squareName(row, col)} selecionada. ${moves.size} movimento${if (moves.size == 1) "" else "s"} legal${if (moves.size == 1) "" else "is"}.")
            }
            invalidate()
        }

        fun clearSelection() {
            selectedRow = -1
            selectedCol = -1
            legalTargets = emptyList()
            hintedMove = null
        }

        fun highlightHint(move: ChessEngine.Move) {
            hintedMove = move
            selectedRow = move.fromRow
            selectedCol = move.fromCol
            legalTargets = listOf(move)
            invalidate()
        }

        fun animateMove(move: ChessEngine.Move, piece: Char, duration: Long, onEnd: () -> Unit) {
            moveAnimator?.cancel()
            lastMove = move
            animatedMove = move
            animatedPiece = piece
            moveProgress = 0f
            moveAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
                this.duration = duration
                interpolator = DecelerateInterpolator()
                addUpdateListener {
                    moveProgress = it.animatedValue as Float
                    invalidate()
                }
                addListener(object : android.animation.AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: android.animation.Animator) {
                        moveProgress = 1f
                        animatedMove = null
                        animatedPiece = ' '
                        invalidate()
                        onEnd()
                    }
                })
                start()
            }
        }

        fun flashCheck() {
            checkFlashStarted = SystemClock.elapsedRealtime()
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            invalidate()
        }

        fun startResultAnimation(winner: ChessEngine.Winner) {
            resultAnimator?.cancel()
            resultWinner = winner
            resultProgress = 0f
            resultAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 1100L
                interpolator = DecelerateInterpolator()
                addUpdateListener {
                    resultProgress = it.animatedValue as Float
                    invalidate()
                }
                start()
            }
        }

        fun resetVisuals() {
            moveAnimator?.cancel()
            resultAnimator?.cancel()
            clearSelection()
            lastMove = null
            animatedMove = null
            animatedPiece = ' '
            moveProgress = 1f
            resultWinner = ChessEngine.Winner.NONE
            resultProgress = 0f
            checkFlashStarted = 0L
            invalidate()
        }
    }
}
