# AIDA 7.5.0

Assistente virtual Android em Kotlin com voz PT-BR, comandos locais do aparelho, memória local, integração opcional com IA e modo Professora de Xadrez.

## Novidades 7.5.0

- Xadrez com animação de peças, último lance destacado e rei em xeque pulsando.
- Reconhecimento confiável de xeque-mate, vitória, derrota e empates.
- Botão para desfazer o último turno.
- AIDA pensa por um tempo visível antes de jogar, em vez de responder instantaneamente.
- Modo professora fala e comenta cada jogada quando ativado.
- Aula de xadrez ampliada.
- Animações de vitória, derrota e empate.
- Tela principal da AIDA com auroras, órbitas, ondas de energia e ripple de toque.

## Funções preservadas

A base mantém voz/TTS, reconhecimento de voz, comandos locais, abertura de apps, mídia, lanterna/câmera, memória, chat texto, quiz, Bíblia, notificações, lembretes, cálculos, configurações, personalidades e os demais módulos existentes no projeto.

## Compilar

O projeto usa minSdk 26, target/compile SDK 35, Java 17, Android Gradle Plugin 8.7.3 e Gradle 8.9.

O workflow do repositório que procura `AIDA_*_PROJETO.zip` automaticamente pode ser mantido sem alterações: basta substituir/adicionar o ZIP desta versão e executar o GitHub Actions.

## IA

A chave da IA é salva nos dados privados do aplicativo quando configurada pelo usuário e não precisa ser embutida no código-fonte. O backend opcional continua na pasta `backend`.
