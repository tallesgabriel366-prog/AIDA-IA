# AIDA 7.6.0

Assistente virtual Android em Kotlin com voz PT-BR, comandos locais do aparelho, memória local, integração opcional com IA e modo Professora de Xadrez.

## Novidades 7.6.0

- Botão Google visível na tela principal.
- Comando de voz para abrir o Google: `abra o Google`.
- Pesquisa direta: `pesquise no Google...`, `Google...` e `abra o Google e pesquise...`.
- Tenta abrir primeiro o app Google e usa navegador como fallback.
- Transições visuais novas entre funções, com feixe de varredura, pulso de energia e rótulo curto da função.
- Botões de atalho com animação de toque e resposta háptica.
- Painel de status com transição suave ao mudar entre ouvindo, pensando e falando.
- Entrada/saída do modo xadrez com transição suave.
- Leitura por voz mais rápida no streaming: o primeiro trecho começa antes e os próximos blocos são menores.
- Removida uma reinicialização redundante do TTS antes de falas locais para reduzir latência em alguns aparelhos.
- Atualizações visuais protegidas para sempre rodarem na thread principal, evitando travamentos em respostas vindas de tarefas de rede.

## Recursos da 7.5 preservados

- Xadrez com animação de peças, último lance destacado e rei em xeque pulsando.
- Xeque-mate, vitória, derrota e empates.
- Desfazer último turno.
- AIDA pensa antes de jogar.
- Professora de xadrez com voz e comentários durante a partida.
- Aula de xadrez ampliada.
- Animações de vitória, derrota e empate.
- Auroras, órbitas, ondas de energia e ripple no núcleo da AIDA.

## Funções preservadas

A base mantém voz/TTS, reconhecimento de voz, comandos locais, abertura de apps, mídia, lanterna/câmera, memória, chat texto, quiz, Bíblia, notificações, lembretes, cálculos, configurações, personalidades e os demais módulos existentes no projeto.

## Compilar

O projeto usa minSdk 26, target/compile SDK 35, Java 17, Android Gradle Plugin 8.7.3 e Gradle 8.9.

O workflow do repositório que procura `AIDA_*_PROJETO.zip` automaticamente pode ser mantido sem alterações: basta adicionar o ZIP desta versão e executar o GitHub Actions.
