AIDA — Wake word em segundo plano (7.2.5 fonte)

Implementado no FONTE:
- serviço de microfone em primeiro plano para escuta em segundo plano;
- só aceita comando iniciado por “AIDA” / “Ei AIDA”;
- também aceita “AIDA” sozinha e o comando em até 8 segundos;
- envia comandos aceitos ao roteador principal executar(), preservando as funções existentes;
- consulta dinâmica dos apps lançáveis instalados, sem lista fixa;
- pesquisa/reprodução de música via MEDIA_PLAY_FROM_SEARCH, com fallback para YouTube;
- não força reconhecimento offline em PT-BR (melhor compatibilidade com Xiaomi/HyperOS);
- não reintroduz NotificationListenerService, SMS, Acessibilidade ou QUERY_ALL_PACKAGES.

APK em dist/AIDA_WAKE_PREFIX_XIAOMI_TEST.apk:
- hotfix compilado sobre a base estável 7.2.4;
- exige “AIDA” / “Ei AIDA” no INÍCIO da mesma frase;
- usa o mesmo roteador de funções da base 7.2.4;
- assinado com a mesma chave da AIDA, v1 + v2, com v2 validado criptograficamente;
- o APK de teste ainda não contém as alterações novas de reprodução direta por pesquisa nem o modo em duas etapas; essas alterações estão no fonte 7.2.5.
