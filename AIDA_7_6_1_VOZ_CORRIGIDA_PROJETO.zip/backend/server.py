import os

from flask import Flask, jsonify, request
from openai import OpenAI


app = Flask(__name__)

SYSTEM_INSTRUCTIONS = """
Você é AIDA, uma assistente virtual brasileira controlada por voz.
Responda sempre em português do Brasil, de forma clara, amigável e breve.
Como a resposta será falada pelo celular, evite markdown, listas longas e URLs.
Não afirme ter executado ações no aparelho; o aplicativo cuida dessas ações.
""".strip()


@app.get("/health")
def health():
    return jsonify({"status": "ok"})


@app.post("/chat")
def chat():
    data = request.get_json(silent=True) or {}
    message = str(data.get("message", "")).strip()
    extra_instructions = str(data.get("system_instructions", "")).strip()
    history = data.get("history", [])

    if not message:
        return jsonify({"error": "A mensagem é obrigatória."}), 400

    if len(message) > 2_000:
        return jsonify({"error": "A mensagem é muito longa."}), 400

    if not os.getenv("OPENAI_API_KEY"):
        return jsonify({"error": "OPENAI_API_KEY não configurada no servidor."}), 503

    try:
        client = OpenAI()
        conversation = []
        if isinstance(history, list):
            for item in history[-8:]:
                if not isinstance(item, dict):
                    continue
                role = "assistant" if item.get("role") in {"assistant", "model"} else "user"
                text = str(item.get("text", "")).strip()
                if text:
                    conversation.append({"role": role, "content": text})
        conversation.append({"role": "user", "content": message})
        instructions = SYSTEM_INSTRUCTIONS
        if extra_instructions:
            instructions += "\n\n" + extra_instructions[:12000]
        response = client.responses.create(
            model=os.getenv("OPENAI_MODEL", "gpt-5.5"),
            instructions=instructions,
            input=conversation,
        )
        return jsonify({"reply": response.output_text.strip()})
    except Exception:
        app.logger.exception("Falha ao consultar a IA")
        return jsonify({"error": "Não foi possível obter uma resposta agora."}), 502


@app.post("/vision")
def vision():
    data = request.get_json(silent=True) or {}
    image = str(data.get("image", "")).strip()

    if not image.startswith("data:image/"):
        return jsonify({"error": "Imagem inválida."}), 400

    if len(image) > 8_000_000:
        return jsonify({"error": "A imagem é muito grande."}), 413

    if not os.getenv("OPENAI_API_KEY"):
        return jsonify({"error": "OPENAI_API_KEY não configurada no servidor."}), 503

    try:
        client = OpenAI()
        response = client.responses.create(
            model=os.getenv("OPENAI_MODEL", "gpt-5.5"),
            instructions=SYSTEM_INSTRUCTIONS,
            input=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "input_text",
                            "text": (
                                "Descreva o que aparece nesta foto para o usuário da AIDA. "
                                "Se houver texto legível, mencione-o. Seja breve e não faça "
                                "diagnósticos médicos nem afirmações de identidade pessoal."
                            ),
                        },
                        {"type": "input_image", "image_url": image, "detail": "low"},
                    ],
                }
            ],
        )
        return jsonify({"reply": response.output_text.strip()})
    except Exception:
        app.logger.exception("Falha ao analisar a imagem")
        return jsonify({"error": "Não foi possível analisar a imagem agora."}), 502


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "8000")), debug=False)
