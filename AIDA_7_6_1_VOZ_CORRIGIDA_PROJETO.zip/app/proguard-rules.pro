# Regras específicas do AIDA podem ser adicionadas aqui.
