package com.aida.assistant

object BibleExtras {
    data class TimelineItem(val periodo: String, val evento: String, val referencia: String)

    val linhaDoTempo = listOf(
        TimelineItem("Origens", "Criação e primeiros relatos de Gênesis", "Gênesis 1–11"),
        TimelineItem("Patriarcas", "Abraão, Isaque, Jacó e José", "Gênesis 12–50"),
        TimelineItem("Êxodo", "Moisés, saída do Egito e aliança no Sinai", "Êxodo–Deuteronômio"),
        TimelineItem("Conquista e juízes", "Josué e o período dos juízes", "Josué–Juízes"),
        TimelineItem("Monarquia", "Saul, Davi e Salomão", "1 Samuel–1 Reis 11"),
        TimelineItem("Reinos divididos", "Israel e Judá, profetas e crises", "1 Reis 12–2 Reis"),
        TimelineItem("Exílio", "Queda de Jerusalém e vida na Babilônia", "2 Reis 24–25; Daniel; Ezequiel"),
        TimelineItem("Retorno", "Reconstrução de Jerusalém e do templo", "Esdras–Neemias"),
        TimelineItem("Vida de Jesus", "Nascimento, ministério, morte e ressurreição", "Mateus–João"),
        TimelineItem("Igreja primitiva", "Pentecostes, missão e expansão", "Atos"),
        TimelineItem("Cartas", "Ensino às primeiras comunidades cristãs", "Romanos–Judas"),
        TimelineItem("Apocalipse", "Visões de esperança, juízo e restauração", "Apocalipse")
    )

    val plano7Dias = listOf(
        "Dia 1 — Salmos 23: confiança e cuidado.",
        "Dia 2 — Mateus 5:1–16: valores do Reino e influência.",
        "Dia 3 — Lucas 15: graça, arrependimento e restauração.",
        "Dia 4 — João 15: permanência, amor e fruto.",
        "Dia 5 — Romanos 12: vida prática, serviço e relações.",
        "Dia 6 — Filipenses 4: alegria, ansiedade, oração e contentamento.",
        "Dia 7 — Tiago 1: perseverança, sabedoria e prática da Palavra."
    )

    val parabolas = mapOf(
        "bom samaritano" to "Lucas 10:25–37 — misericórdia prática que ultrapassa barreiras sociais.",
        "filho prodigo" to "Lucas 15:11–32 — arrependimento, acolhimento e o desafio de lidar com a graça dada ao outro.",
        "semeador" to "Mateus 13:1–23 — diferentes respostas à mensagem e importância de um coração receptivo.",
        "ovelha perdida" to "Lucas 15:1–7 — valor de quem está perdido e alegria da restauração.",
        "talentos" to "Mateus 25:14–30 — responsabilidade no uso do que foi confiado a cada pessoa."
    )
}
