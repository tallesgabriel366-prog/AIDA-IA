package com.aida.assistant

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.SearchManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.AudioAttributes
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.os.BatteryManager
import android.view.KeyEvent
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Escuta em segundo plano da AIDA.
 *
 * Regra de segurança: um comando só é aceito quando:
 * 1) a mesma frase começa por "AIDA" / "Ei AIDA"; ou
 * 2) o usuário disse apenas "AIDA" e fala o comando dentro da janela de ativação.
 *
 * Frases que não passam pelo wake word são ignoradas.
 */
class VoiceWakeService : Service() {
    private var recognizer: SpeechRecognizer? = null
    private var restarting = false
    private var destroyed = false
    private var armedUntil = 0L
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pendingTtsText: String? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIFICATION_ID, foregroundNotification())
        startRecognizer()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (recognizer == null && !destroyed) startRecognizer()
        return START_STICKY
    }

    private fun foregroundNotification(): android.app.Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            android.app.Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            android.app.Notification.Builder(this)
        }
        return builder
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("AIDA • Escuta em segundo plano")
            .setContentText("Diga “AIDA” antes do comando")
            .setOngoing(true)
            .setCategory(android.app.Notification.CATEGORY_SERVICE)
            .setContentIntent(openIntent)
            .build()
    }

    private fun startRecognizer() {
        if (destroyed ||
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED ||
            !SpeechRecognizer.isRecognitionAvailable(this)
        ) return

        recognizer?.cancel()
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) = Unit
                override fun onBeginningOfSpeech() = Unit
                override fun onRmsChanged(rmsdB: Float) = Unit
                override fun onBufferReceived(buffer: ByteArray?) = Unit
                override fun onEndOfSpeech() = Unit
                override fun onPartialResults(partialResults: Bundle?) = Unit
                override fun onEvent(eventType: Int, params: Bundle?) = Unit

                override fun onError(error: Int) {
                    val delay = when (error) {
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> 1000L
                        SpeechRecognizer.ERROR_NO_MATCH,
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> 260L
                        else -> 650L
                    }
                    restart(delay)
                }

                override fun onResults(results: Bundle?) {
                    val heard = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                        ?.trim()
                        .orEmpty()

                    val now = System.currentTimeMillis()
                    val wake = WAKE_PREFIX.matchEntire(heard)
                    var dispatched = false

                    if (wake != null) {
                        val command = wake.groupValues.getOrNull(1)?.trim().orEmpty()
                        if (command.isBlank()) {
                            // "AIDA" sozinha arma a próxima frase por alguns segundos.
                            armedUntil = now + ARM_WINDOW_MS
                            acknowledgeWake()
                        } else {
                            armedUntil = 0L
                            dispatchCommand(command)
                            dispatched = true
                        }
                    } else if (now <= armedUntil && heard.isNotBlank()) {
                        armedUntil = 0L
                        dispatchCommand(heard)
                        dispatched = true
                    } else if (now > armedUntil) {
                        armedUntil = 0L
                    }

                    restart(if (dispatched) 900L else 220L)
                }
            })
            startListening(recognizerIntent())
        }
    }

    private fun acknowledgeWake() {
        // Feedback curto, sem iniciar TTS pesado no serviço.
        runCatching {
            val vibrator = if (Build.VERSION.SDK_INT >= 31) {
                val manager = getSystemService(android.os.VibratorManager::class.java)
                manager.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(VIBRATOR_SERVICE) as android.os.Vibrator
            }
            if (Build.VERSION.SDK_INT >= 26) {
                vibrator.vibrate(android.os.VibrationEffect.createOneShot(35L, 70))
            } else {
                @Suppress("DEPRECATION") vibrator.vibrate(35L)
            }
        }
    }

    private fun dispatchCommand(command: String) {
        val clean = command.trim()
        if (clean.isBlank()) return

        // Comandos de sistema essenciais funcionam mesmo quando a Activity já
        // foi destruída. O restante continua indo para o mesmo núcleo executar().
        if (handleDirectBackgroundCommand(clean)) return

        sendBroadcast(Intent(ACTION_WAKE_COMMAND).apply {
            setPackage(packageName)
            putExtra(EXTRA_COMMAND, clean)
        })

        // Se a Activity não estiver viva, o comando continua disponível para o
        // usuário na notificação. Android moderno restringe abrir Activities
        // arbitrariamente a partir do segundo plano.
        showCommandNotification(clean)
    }

    private fun handleDirectBackgroundCommand(raw: String): Boolean {
        val cmd = normalize(raw)

        if (cmd.contains("que horas") || cmd == "horas" || cmd.contains("horas sao") || cmd.contains("hora agora")) {
            val hora = SimpleDateFormat("HH:mm", Locale("pt", "BR")).format(Date())
            speak("Agora são $hora.")
            return true
        }

        val volumePercent = Regex(".*\\bvolume(?: da midia)?(?: em| para)?\\s*(\\d{1,3})(?:\\s*por cento|%)?.*").matchEntire(cmd)
            ?.groupValues?.getOrNull(1)?.toIntOrNull()
        if (volumePercent != null) {
            setMediaVolume(volumePercent)
            return true
        }
        if (cmd.contains("aumentar volume") || cmd.contains("volume mais alto")) {
            val audio = getSystemService(AUDIO_SERVICE) as AudioManager
            audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            speak("Aumentei o volume.")
            return true
        }
        if (cmd.contains("diminuir volume") || cmd.contains("abaixar volume")) {
            val audio = getSystemService(AUDIO_SERVICE) as AudioManager
            audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            speak("Diminuí o volume.")
            return true
        }

        val brightnessPercent = Regex(".*\\bbrilho(?: em| para)?\\s*(\\d{1,3})(?:\\s*por cento|%)?.*").matchEntire(cmd)
            ?.groupValues?.getOrNull(1)?.toIntOrNull()
        if (brightnessPercent != null) {
            setBrightness(brightnessPercent)
            return true
        }

        // Verifique DESLIGAR antes de LIGAR: "desligar" contém a palavra "ligar".
        if (cmd.contains("desligar lanterna") || cmd.contains("apagar lanterna")) {
            setTorch(false)
            return true
        }
        if (cmd.contains("ligar lanterna") || cmd.contains("acender lanterna")) {
            setTorch(true)
            return true
        }

        if (cmd.contains("proxima musica") || cmd.contains("proxima faixa") ||
            cmd.contains("mudar musica") || cmd.contains("trocar musica") || cmd.contains("pular musica")) {
            mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT)
            speak("Pulando para a próxima música.")
            return true
        }
        if (cmd.contains("musica anterior") || cmd.contains("faixa anterior") || cmd.contains("voltar musica")) {
            mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
            speak("Voltando a música.")
            return true
        }
        if (cmd.contains("pausar musica") || cmd == "pause" || cmd.contains("pausar midia")) {
            mediaKey(KeyEvent.KEYCODE_MEDIA_PAUSE)
            return true
        }
        if (cmd.contains("continuar musica") || cmd.contains("retomar musica") || cmd == "play") {
            mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY)
            return true
        }

        if (cmd.contains("nao perturbe") || cmd.contains("não perturbe")) {
            val desligar = cmd.contains("desativ") || cmd.contains("deslig") || cmd.contains("tirar")
            setDoNotDisturb(!desligar)
            return true
        }

        if (cmd.contains("bateria") && (cmd.contains("quanto") || cmd.contains("nivel") || cmd.contains("porcent"))) {
            val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
            val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            speak(if (pct in 0..100) "A bateria está em $pct por cento." else "Não consegui consultar a bateria agora.")
            return true
        }

        if ((cmd.contains("youtube") && Regex(".*\\b(pesquise|pesquisar|pesquisa|busque|buscar|procure)\\b.*").matches(cmd))) {
            val query = raw.replace(Regex("(?i)^.*?youtube\\s*(?:e\\s*)?(?:pesquise|pesquisar|pesquisa|busque|buscar|procure)?\\s*(?:a\\s+musica|a\\s+música|musica|música)?\\s*"), "").trim()
            if (query.isNotBlank()) {
                openYouTubeSearch(query)
                return true
            }
        }

        val playMatch = Regex("(?i)^(?:toque|tocar|coloque|bote|ponha|reproduza)(?:\\s+a)?(?:\\s+musica|\\s+música)?\\s+(.+)$").find(raw.trim())
        if (playMatch != null) {
            val query = playMatch.groupValues[1].trim()
            if (query.isNotBlank()) {
                playFromSearch(query)
                return true
            }
        }

        val openMatch = Regex("(?i)^(?:abra|abrir|inicie|iniciar|execute|executar)\\s+(?:o\\s+|a\\s+)?(.+)$").find(raw.trim())
        if (openMatch != null) {
            val appName = openMatch.groupValues[1].trim()
            if (appName.isNotBlank() && !normalize(appName).contains("youtube e ")) {
                if (openInstalledApp(appName)) return true
            }
        }

        return false
    }

    private fun mediaKey(keyCode: Int) {
        val audio = getSystemService(AUDIO_SERVICE) as AudioManager
        val down = KeyEvent(KeyEvent.ACTION_DOWN, keyCode)
        val up = KeyEvent(KeyEvent.ACTION_UP, keyCode)
        audio.dispatchMediaKeyEvent(down)
        audio.dispatchMediaKeyEvent(up)
    }

    private fun setDoNotDisturb(enabled: Boolean) {
        val manager = getSystemService(NotificationManager::class.java)
        if (!manager.isNotificationPolicyAccessGranted) {
            speak("Para controlar o Não Perturbe, permita esse acesso especial nas configurações da AIDA.")
            showCommandNotification("Permitir acesso ao Não Perturbe")
            return
        }
        runCatching {
            manager.setInterruptionFilter(
                if (enabled) NotificationManager.INTERRUPTION_FILTER_PRIORITY
                else NotificationManager.INTERRUPTION_FILTER_ALL
            )
        }.onSuccess {
            speak(if (enabled) "Não Perturbe ativado." else "Não Perturbe desativado.")
        }.onFailure {
            speak("Não consegui alterar o Não Perturbe agora.")
        }
    }

    private fun setMediaVolume(percent: Int) {
        val value = percent.coerceIn(0, 100)
        val audio = getSystemService(AUDIO_SERVICE) as AudioManager
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val target = ((value / 100f) * max).toInt().coerceIn(0, max)
        audio.setStreamVolume(AudioManager.STREAM_MUSIC, target, AudioManager.FLAG_SHOW_UI)
        speak("Volume em $value por cento.")
    }

    private fun setBrightness(percent: Int) {
        val value = percent.coerceIn(1, 100)
        if (!Settings.System.canWrite(this)) {
            speak("Para ajustar o brilho em segundo plano, permita que a AIDA modifique configurações do sistema.")
            showCommandNotification("Permitir brilho: toque para abrir a AIDA e autorizar")
            return
        }
        runCatching {
            Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, ((value / 100f) * 255).toInt().coerceIn(1, 255))
            speak("Brilho em $value por cento.")
        }.onFailure { speak("Não consegui ajustar o brilho agora.") }
    }

    private fun setTorch(enabled: Boolean) {
        val camera = getSystemService(CAMERA_SERVICE) as android.hardware.camera2.CameraManager
        val id = runCatching {
            camera.cameraIdList.firstOrNull { camera.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
        }.getOrNull()
        if (id == null) {
            speak("Não encontrei uma lanterna disponível.")
            return
        }
        runCatching { camera.setTorchMode(id, enabled) }
            .onSuccess { speak(if (enabled) "Lanterna ligada." else "Lanterna desligada.") }
            .onFailure { speak("Não consegui controlar a lanterna agora.") }
    }

    private fun openInstalledApp(requestedName: String): Boolean {
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val activities = packageManager.queryIntentActivities(query, 0)
        val wanted = normalize(requestedName)
        val candidates = activities.map { info ->
            val label = info.loadLabel(packageManager)?.toString().orEmpty()
            Triple(info, label, normalize(label))
        }
        val best = candidates.firstOrNull { it.third == wanted }
            ?: candidates.firstOrNull { it.third.startsWith(wanted) || wanted.startsWith(it.third) }
            ?: candidates.firstOrNull { it.third.contains(wanted) || wanted.contains(it.third) }
            ?: return false

        val component = android.content.ComponentName(best.first.activityInfo.packageName, best.first.activityInfo.name)
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(component)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        val ok = runCatching { startActivity(intent) }.isSuccess
        if (ok) speak("Abrindo ${best.second}.") else showCommandNotification("Abrir ${best.second}")
        return true
    }

    private fun playFromSearch(query: String) {
        val intent = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
            putExtra(SearchManager.QUERY, query)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val ok = runCatching { startActivity(intent) }.isSuccess
        if (ok) {
            speak("Tocando $query.")
        } else {
            openYouTubeSearch(query)
        }
    }

    private fun openYouTubeSearch(query: String) {
        val url = Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query))
        val intent = Intent(Intent.ACTION_VIEW, url).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val youtube = packageManager.getLaunchIntentForPackage("com.google.android.youtube")
        if (youtube != null) intent.setPackage("com.google.android.youtube")
        val ok = runCatching { startActivity(intent) }.isSuccess
        if (ok) speak("Pesquisando $query no YouTube.") else showCommandNotification("Pesquisar no YouTube: $query")
    }

    private fun showCommandNotification(clean: String) {
        val pending = PendingIntent.getActivity(
            this,
            (System.currentTimeMillis() % 100000).toInt(),
            Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                putExtra(EXTRA_COMMAND, clean)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            android.app.Notification.Builder(this, CHANNEL_COMMAND_ID)
        } else {
            @Suppress("DEPRECATION") android.app.Notification.Builder(this)
        }
        val notification = builder
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("AIDA ouviu um comando")
            .setContentText(clean.take(120))
            .setAutoCancel(true)
            .setContentIntent(pending)
            .build()
        getSystemService(NotificationManager::class.java)
            .notify((System.currentTimeMillis() % 100000).toInt(), notification)
    }

    private fun speak(text: String) {
        if (text.isBlank()) return
        pendingTtsText = text
        if (tts == null) {
            tts = TextToSpeech(applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    val local = tts
                    val lang = local?.setLanguage(Locale("pt", "BR")) ?: TextToSpeech.ERROR
                    if (lang == TextToSpeech.LANG_MISSING_DATA || lang == TextToSpeech.LANG_NOT_SUPPORTED || lang == TextToSpeech.ERROR) {
                        local?.setLanguage(Locale.getDefault())
                    }
                    local?.setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    local?.setSpeechRate(1.08f)
                    ttsReady = true
                    val pending = pendingTtsText
                    pendingTtsText = null
                    if (!pending.isNullOrBlank()) {
                        local?.stop()
                        local?.speak(pending, TextToSpeech.QUEUE_FLUSH, null, "aida-bg-${System.currentTimeMillis()}")
                    }
                }
            }
        } else if (ttsReady) {
            pendingTtsText = null
            tts?.stop()
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "aida-bg-${System.currentTimeMillis()}")
        }
    }

    private fun normalize(value: String): String = Normalizer.normalize(
        value.lowercase(Locale("pt", "BR")), Normalizer.Form.NFD
    ).replace(Regex("\\p{Mn}+"), "")
        .replace(Regex("[^a-z0-9 ]"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun recognizerIntent() = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        // Não forçamos offline: alguns Xiaomi não têm o pacote de reconhecimento
        // offline em PT-BR e isso faria o wake word parar de responder.
    }

    private fun restart(delay: Long) {
        if (destroyed || restarting) return
        restarting = true
        android.os.Handler(mainLooper).postDelayed({
            restarting = false
            startRecognizer()
        }, delay)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    "AIDA em segundo plano",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "Mantém o wake word AIDA ativo com o microfone em segundo plano."
                    setSound(null, null)
                }
            )
            manager.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_COMMAND_ID,
                    "Comandos da AIDA",
                    NotificationManager.IMPORTANCE_DEFAULT
                )
            )
        }
    }

    override fun onDestroy() {
        destroyed = true
        armedUntil = 0L
        recognizer?.cancel()
        recognizer?.destroy()
        recognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
        ttsReady = false
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_WAKE_COMMAND = "com.aida.assistant.WAKE_COMMAND"
        const val EXTRA_COMMAND = "aida_command"
        private const val CHANNEL_ID = "aida_voice"
        private const val CHANNEL_COMMAND_ID = "aida_voice_commands"
        private const val NOTIFICATION_ID = 2101
        private const val ARM_WINDOW_MS = 8_000L

        // matchEntire + ^/$ = AIDA precisa estar ANTES do comando.
        private val WAKE_PREFIX = Regex(
            "(?i)^\\s*(?:ei\\s+)?aida\\b[,:]?\\s*(.*)$"
        )
    }
}
