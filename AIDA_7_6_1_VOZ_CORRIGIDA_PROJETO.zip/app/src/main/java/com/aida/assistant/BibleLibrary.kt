package com.aida.assistant

data class BibleStory(val titulo: String, val referencia: String, val resumo: String, val licao: String)
data class BibleCharacter(val nome: String, val referencias: String, val resumo: String, val destaque: String)

object BibleLibrary {
    val historias = listOf(
        BibleStory("A criação", "Gênesis 1–2", "O texto de Gênesis apresenta Deus como criador do universo, da vida e da humanidade, organizando a criação e atribuindo dignidade especial ao ser humano.", "Responsabilidade, propósito e cuidado com a criação."),
        BibleStory("Noé e o dilúvio", "Gênesis 6–9", "Noé recebe a missão de construir uma arca em meio a uma geração violenta. Depois do dilúvio, o arco-íris aparece como sinal da aliança relatada no texto.", "Obediência, preservação da vida e compromisso."),
        BibleStory("O chamado de Abraão", "Gênesis 12", "Abraão é chamado a deixar sua terra e seguir para um lugar que Deus mostraria, recebendo promessas relacionadas a descendência e bênção.", "Fé que se transforma em decisão e caminhada."),
        BibleStory("José no Egito", "Gênesis 37–50", "José é vendido pelos irmãos, passa por injustiças e chega a uma posição de liderança no Egito, onde depois ajuda sua família durante a fome.", "Perseverança, sabedoria e reconciliação."),
        BibleStory("Moisés e o êxodo", "Êxodo 1–15", "Moisés é chamado para confrontar Faraó e liderar a saída dos israelitas do Egito. O relato culmina na travessia do mar e no início de uma nova etapa para o povo.", "Libertação, coragem e liderança responsável."),
        BibleStory("Os Dez Mandamentos", "Êxodo 19–20", "No Sinai, o texto apresenta uma aliança com mandamentos que orientam a relação com Deus e com o próximo.", "Ética, responsabilidade e limites que protegem a convivência."),
        BibleStory("Josué e Jericó", "Josué 6", "Israel chega a Jericó e o relato descreve uma estratégia incomum envolvendo marchas ao redor da cidade antes da queda das muralhas.", "Confiança, disciplina e obediência ao plano proposto."),
        BibleStory("Rute e Noemi", "Rute 1–4", "Rute decide permanecer ao lado de Noemi, recomeça a vida em Belém e sua história passa a integrar a genealogia davídica.", "Lealdade, cuidado familiar e esperança em recomeços."),
        BibleStory("Davi e Golias", "1 Samuel 17", "O jovem Davi enfrenta o guerreiro filisteu Golias sem depender da armadura convencional, confiando em Deus e usando sua habilidade com a funda.", "Coragem não é ausência de medo; preparo e convicção importam."),
        BibleStory("Salomão pede sabedoria", "1 Reis 3", "Ao iniciar seu reinado, Salomão pede discernimento para governar em vez de riqueza ou longa vida.", "Sabedoria e responsabilidade devem vir antes do poder."),
        BibleStory("Elias no Carmelo", "1 Reis 18", "Elias confronta os profetas de Baal no monte Carmelo em um episódio que questiona a idolatria e chama o povo a uma decisão.", "Coerência entre crença e prática."),
        BibleStory("Daniel na cova dos leões", "Daniel 6", "Daniel mantém sua prática de oração apesar de um decreto que a proibia e é lançado na cova dos leões, sendo preservado no relato.", "Integridade e fidelidade sob pressão."),
        BibleStory("Ester diante do rei", "Ester 4–8", "Ester assume o risco de se apresentar ao rei para interceder por seu povo diante de uma ameaça de extermínio.", "Coragem, responsabilidade e uso da influência para proteger outros."),
        BibleStory("Jonas e Nínive", "Jonas 1–4", "Jonas tenta fugir de sua missão, passa pela experiência do grande peixe e depois anuncia uma mensagem a Nínive, que responde com arrependimento.", "Misericórdia pode alcançar até quem consideramos adversário."),
        BibleStory("O nascimento de Jesus", "Mateus 1–2; Lucas 1–2", "Os evangelhos narram o nascimento de Jesus em Belém, destacando promessa, humildade e diferentes testemunhas do acontecimento.", "Esperança pode surgir em cenários simples e improváveis."),
        BibleStory("O bom samaritano", "Lucas 10:25–37", "Jesus conta a história de um homem ferido que é ajudado por um samaritano, alguém de um grupo visto com hostilidade por muitos ouvintes da época.", "Próximo é quem pratica misericórdia, não apenas quem pertence ao nosso grupo."),
        BibleStory("O filho pródigo", "Lucas 15:11–32", "Um filho abandona a casa, desperdiça seus recursos e retorna arrependido. O pai o recebe, enquanto o irmão mais velho reage com ressentimento.", "Arrependimento, restauração e o desafio de celebrar a graça dada ao outro."),
        BibleStory("Jesus acalma a tempestade", "Marcos 4:35–41", "Durante uma tempestade no mar, os discípulos entram em pânico e Jesus acalma o vento e as ondas, levando-os a refletir sobre sua identidade.", "Fé em meio ao medo e confiança quando não controlamos as circunstâncias."),
        BibleStory("A ressurreição", "Mateus 28; Marcos 16; Lucas 24; João 20", "Os quatro evangelhos apresentam o túmulo vazio e testemunhos de encontros com Jesus ressuscitado, núcleo da esperança cristã.", "A fé cristã encontra na ressurreição sua mensagem central de esperança."),
        BibleStory("Pentecostes", "Atos 2", "Os discípulos recebem o Espírito Santo, pessoas de diferentes línguas ouvem a mensagem e nasce uma comunidade marcada por ensino, comunhão e partilha.", "Missão, diversidade e vida comunitária.")
    )

    val personagens = listOf(
        BibleCharacter("Adão", "Gênesis 1–5", "Apresentado como o primeiro homem no relato de Gênesis e colocado no jardim do Éden.", "Sua história é usada para discutir criação, responsabilidade, escolha e consequências."),
        BibleCharacter("Eva", "Gênesis 2–4", "Apresentada como a primeira mulher e companheira de Adão no relato do Éden.", "Sua narrativa está ligada à humanidade, escolhas e consequências."),
        BibleCharacter("Noé", "Gênesis 6–9", "Homem descrito como justo em sua geração e encarregado de construir a arca.", "Obediência em um contexto difícil e preservação da vida."),
        BibleCharacter("Abraão", "Gênesis 11–25", "Patriarca chamado a deixar sua terra, figura central das promessas de descendência e bênção.", "Fé, espera, falhas humanas e confiança."),
        BibleCharacter("Sara", "Gênesis 11–23", "Esposa de Abraão e mãe de Isaque, participa da narrativa das promessas feitas à família.", "Esperança em meio à longa espera."),
        BibleCharacter("Isaque", "Gênesis 21–35", "Filho de Abraão e Sara e pai de Esaú e Jacó.", "Continuidade da aliança e relações familiares complexas."),
        BibleCharacter("Jacó", "Gênesis 25–50", "Filho de Isaque, também chamado Israel, pai dos filhos ligados às tribos de Israel.", "Transformação de caráter, conflitos familiares e reconciliação."),
        BibleCharacter("José", "Gênesis 30–50", "Filho de Jacó vendido pelos irmãos, torna-se administrador no Egito e depois reencontra a família.", "Resiliência, sabedoria, perdão e providência."),
        BibleCharacter("Moisés", "Êxodo–Deuteronômio", "Líder do êxodo, mediador da aliança no Sinai e figura central da Torá.", "Liderança, intercessão, limites humanos e missão."),
        BibleCharacter("Miriã", "Êxodo 2; 15; Números 12", "Irmã de Moisés e Arão, apresentada como profetisa e liderança entre o povo.", "Participação feminina na liderança e responsabilidade."),
        BibleCharacter("Josué", "Êxodo–Josué", "Auxiliar de Moisés que assume a liderança de Israel na entrada em Canaã.", "Coragem, continuidade de missão e disciplina."),
        BibleCharacter("Débora", "Juízes 4–5", "Profetisa e juíza que exerce liderança e participa da libertação de Israel em seu período.", "Coragem, discernimento e liderança."),
        BibleCharacter("Rute", "Livro de Rute", "Moabita que permanece fiel a Noemi e constrói uma nova vida em Belém.", "Lealdade, recomeço e inclusão."),
        BibleCharacter("Samuel", "1 Samuel 1–25", "Profeta e juiz que participa da transição para a monarquia e unge Saul e Davi.", "Escuta, liderança espiritual e responsabilidade pública."),
        BibleCharacter("Saul", "1 Samuel 9–31", "Primeiro rei de Israel no relato de Samuel, começa com potencial mas enfrenta conflitos de obediência e liderança.", "Poder sem maturidade pode se tornar instável."),
        BibleCharacter("Davi", "1 Samuel 16–1 Reis 2", "Pastor, guerreiro e rei de Israel; personagem complexo associado a muitos salmos.", "Coragem e fé convivem com falhas sérias e necessidade de arrependimento."),
        BibleCharacter("Salomão", "1 Reis 1–11; Provérbios", "Rei associado à sabedoria, à construção do templo e a um período de grande prosperidade.", "Sabedoria precisa ser acompanhada de fidelidade e autocontrole."),
        BibleCharacter("Elias", "1 Reis 17–2 Reis 2", "Profeta que confronta idolatria e injustiça durante o reinado de Acabe.", "Coragem pública e também fragilidade humana."),
        BibleCharacter("Eliseu", "1 Reis 19; 2 Reis 2–13", "Sucessor de Elias, ligado a diversos relatos de orientação profética e milagres.", "Serviço, continuidade e atenção às necessidades concretas."),
        BibleCharacter("Ester", "Livro de Ester", "Rainha que arrisca sua posição para interceder por seu povo diante de uma ameaça.", "Coragem e responsabilidade no uso da influência."),
        BibleCharacter("Daniel", "Livro de Daniel", "Jovem judeu levado para a Babilônia que mantém sua identidade e atua em ambientes de governo.", "Integridade, sabedoria e fidelidade em cultura diferente."),
        BibleCharacter("Maria", "Mateus 1–2; Lucas 1–2; João 2; 19; Atos 1", "Mãe de Jesus, apresentada nos evangelhos como participante decisiva dos relatos da infância e presente em momentos importantes.", "Disponibilidade, coragem e reflexão."),
        BibleCharacter("João Batista", "Mateus 3; Marcos 1; Lucas 3; João 1", "Pregador que chama ao arrependimento e prepara o caminho para o ministério de Jesus.", "Missão clara, humildade e coragem profética."),
        BibleCharacter("Pedro", "Evangelhos; Atos; 1–2 Pedro", "Discípulo de Jesus que demonstra impulsividade, falha durante a prisão de Jesus e depois assume papel importante na igreja primitiva.", "Fracasso não precisa ser o capítulo final; restauração pode gerar maturidade."),
        BibleCharacter("João", "Evangelhos; tradição joanina", "Um dos doze discípulos, filho de Zebedeu e irmão de Tiago, associado pela tradição cristã a escritos joaninos.", "Discipulado, testemunho e amor."),
        BibleCharacter("Marta", "Lucas 10; João 11–12", "Irmã de Maria e Lázaro, aparece servindo, dialogando com Jesus e expressando fé diante da morte do irmão.", "Serviço precisa caminhar com presença, fé e prioridade."),
        BibleCharacter("Maria Madalena", "Evangelhos", "Seguidora de Jesus e uma das principais testemunhas dos relatos da crucificação, sepultamento e ressurreição.", "Fidelidade, testemunho e transformação."),
        BibleCharacter("Paulo", "Atos; cartas paulinas", "Antigo perseguidor de cristãos que passa por uma conversão e se torna missionário e autor de cartas fundamentais do Novo Testamento.", "Transformação, missão, argumentação e perseverança."),
        BibleCharacter("Barnabé", "Atos 4; 9; 11–15", "Líder da igreja primitiva conhecido por encorajar pessoas e apoiar Paulo em um momento de desconfiança.", "Encorajamento e capacidade de enxergar potencial nos outros."),
        BibleCharacter("Timóteo", "Atos; 1–2 Timóteo", "Jovem colaborador de Paulo envolvido em liderança e ensino nas primeiras comunidades cristãs.", "Crescimento, responsabilidade e mentoria.")
    )

    fun personagemPorNome(nome: String): BibleCharacter? {
        val alvo = normalizar(nome)
        return personagens.firstOrNull { normalizar(it.nome) == alvo || alvo.contains(normalizar(it.nome)) }
    }

    private fun normalizar(texto: String): String = java.text.Normalizer.normalize(texto.lowercase(), java.text.Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "")
        .replace(Regex("[^a-z0-9 ]"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()
}
