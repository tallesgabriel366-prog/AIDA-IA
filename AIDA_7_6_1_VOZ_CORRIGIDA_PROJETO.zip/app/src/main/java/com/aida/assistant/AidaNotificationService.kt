package com.aida.assistant

import android.app.Notification
import android.os.Build
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONArray
import org.json.JSONObject

class AidaNotificationService : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        // Assim que o usuário libera o acesso, aproveita as notificações que ainda
        // estão ativas para a AIDA não começar com a lista vazia.
        runCatching {
            activeNotifications
                ?.filterNot { it.packageName == packageName }
                ?.takeLast(25)
                ?.forEach { salvarNotificacao(it) }
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn?.let { salvarNotificacao(it) }
    }

    private fun salvarNotificacao(source: StatusBarNotification) {
        if (source.packageName == packageName) return
        val notification = source.notification ?: return
        val extras = notification.extras ?: return

        val tituloBasico = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val tituloConversa = if (Build.VERSION.SDK_INT >= 24) {
            extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString()?.trim().orEmpty()
        } else ""
        val title = tituloConversa.ifBlank { tituloBasico }

        val mensagens = if (Build.VERSION.SDK_INT >= 24) {
            runCatching {
                val bundles = extras.getParcelableArray(Notification.EXTRA_MESSAGES)
                Notification.MessagingStyle.Message.getMessagesFromBundleArray(bundles)
                    .orEmpty()
                    .takeLast(8)
                    .mapNotNull { message ->
                        val texto = message.text?.toString()?.trim().orEmpty()
                        if (texto.isBlank()) return@mapNotNull null
                        val remetente = if (Build.VERSION.SDK_INT >= 28) {
                            message.senderPerson?.name?.toString()?.trim().orEmpty()
                        } else {
                            @Suppress("DEPRECATION")
                            message.sender?.toString()?.trim().orEmpty()
                        }
                        if (remetente.isBlank()) texto else "$remetente: $texto"
                    }
                    .joinToString("\n")
            }.getOrDefault("")
        } else ""

        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()?.trim().orEmpty()
        val lines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
            ?.map { it.toString().trim() }
            ?.filter { it.isNotBlank() }
            ?.takeLast(8)
            ?.joinToString("\n")
            .orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
        val subText = extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString()?.trim().orEmpty()

        val body = mensagens
            .ifBlank { bigText }
            .ifBlank { lines }
            .ifBlank { text }
            .ifBlank { subText }

        if (title.isBlank() && body.isBlank()) return

        val appName = runCatching {
            val info = packageManager.getApplicationInfo(source.packageName, 0)
            packageManager.getApplicationLabel(info).toString()
        }.getOrDefault(source.packageName)

        val prefs = getSharedPreferences("aida_notifications", MODE_PRIVATE)
        val atual = runCatching { JSONArray(prefs.getString("recent_json", "[]")) }.getOrDefault(JSONArray())
        val now = System.currentTimeMillis()

        // Vários apps atualizam a mesma notificação em sequência. Evita guardar a
        // mesma mensagem várias vezes e piorar o resumo.
        for (i in (atual.length() - 1) downTo (atual.length() - 6).coerceAtLeast(0)) {
            val item = atual.optJSONObject(i) ?: continue
            val igual = item.optString("package") == source.packageName &&
                item.optString("title") == title.take(180) &&
                item.optString("text") == body.take(1200)
            if (igual && now - item.optLong("time", 0L) < 15_000L) return
        }

        val novo = JSONObject()
            .put("app", appName.take(100))
            .put("package", source.packageName)
            .put("title", title.take(180))
            .put("text", body.take(1200))
            .put("time", now)

        val saida = JSONArray()
        val inicio = (atual.length() - 59).coerceAtLeast(0)
        for (i in inicio until atual.length()) saida.put(atual.optJSONObject(i))
        saida.put(novo)
        prefs.edit().putString("recent_json", saida.toString()).apply()
    }
}
