package com.aida.assistant

data class BibleNarrative(
    val titulo: String,
    val referencia: String,
    val capitulos: List<String>
)

object BibleNarratives {
    val historias = listOf(
        BibleNarrative(
            "José do Egito", "Gênesis 37–50", listOf(
                "Capítulo 1. José era filho de Jacó e recebeu do pai uma túnica especial. Seus sonhos indicavam que um dia teria posição de destaque, mas isso aumentou o ciúme dos irmãos. Eles o venderam a mercadores que seguiam para o Egito. Mesmo arrancado de casa e colocado numa realidade desconhecida, José continuou sua caminhada sem saber como aquela perda seria usada no futuro.",
                "Capítulo 2. No Egito, José serviu na casa de Potifar, foi acusado injustamente e acabou preso. Na prisão interpretou sonhos com sabedoria. Anos depois, o faraó teve sonhos que ninguém conseguia explicar. José foi chamado, atribuiu a Deus a interpretação e anunciou sete anos de fartura seguidos por sete anos de fome. O faraó o colocou como administrador para preparar o país.",
                "Capítulo 3. A fome alcançou Canaã e os irmãos de José foram ao Egito comprar alimento. Depois de testar se haviam mudado, José revelou sua identidade. Em vez de buscar vingança, escolheu reconciliação e proteção para a família. A história mostra como sofrimento, responsabilidade, perdão e providência se cruzam ao longo de muitos anos."
            )
        ),
        BibleNarrative(
            "Moisés e o Êxodo", "Êxodo 1–20", listOf(
                "Capítulo 1. Os israelitas viviam oprimidos no Egito. Moisés nasceu num período de perseguição e foi preservado ainda bebê, crescendo na casa de Faraó. Já adulto, fugiu para Midiã. Anos depois, diante da sarça ardente, recebeu o chamado para voltar ao Egito e enfrentar Faraó, levando a mensagem de libertação ao povo.",
                "Capítulo 2. Moisés e Arão confrontaram Faraó. Vieram as pragas, mostrando a incapacidade do poder egípcio de impedir o propósito de libertação. Na noite da Páscoa, as famílias israelitas receberam instruções específicas e depois partiram. Diante do mar e do exército atrás deles, o caminho pareceu impossível, mas a travessia marcou definitivamente a saída da escravidão.",
                "Capítulo 3. No deserto, o povo enfrentou sede, fome e insegurança. Recebeu provisão e aprendeu dependência. No Sinai, a aliança ganhou forma com os Dez Mandamentos e outras orientações para a vida comunitária. O Êxodo não é apenas a saída de um lugar; é a passagem de um povo escravizado para uma comunidade chamada a viver com identidade, responsabilidade e fé."
            )
        ),
        BibleNarrative(
            "Davi", "1 Samuel 16 – 1 Reis 2", listOf(
                "Capítulo 1. Davi aparece primeiro como jovem pastor em Belém. Samuel o unge, embora o rei Saul ainda estivesse no trono. No confronto com Golias, Davi recusa confiar apenas em armadura e força física. A vitória o torna conhecido, mas também desperta a insegurança de Saul, iniciando anos de perseguição.",
                "Capítulo 2. Mesmo tendo oportunidades de matar Saul, Davi evita tomar o reino pela violência. Depois da morte de Saul, torna-se rei e estabelece Jerusalém como centro político. Seu governo reúne conquistas e decisões importantes, mas também apresenta falhas graves. O episódio com Bate-Seba mostra abuso de poder, pecado, confronto profético e consequências dolorosas.",
                "Capítulo 3. A família de Davi atravessa conflitos e rebeliões, incluindo a crise com Absalão. Apesar de suas contradições, Davi permanece uma figura central na história bíblica, lembrado por sua busca por Deus, seus salmos e a promessa ligada à sua linhagem. Sua história combina coragem, liderança, arrependimento e as consequências reais das escolhas."
            )
        ),
        BibleNarrative(
            "Ester", "Ester 1–10", listOf(
                "Capítulo 1. Ester, uma jovem judia criada por Mardoqueu, torna-se rainha no império persa sem inicialmente revelar sua origem. O oficial Hamã recebe grande autoridade e se enfurece quando Mardoqueu não se curva diante dele. Seu ressentimento cresce até virar um plano para destruir todo o povo judeu no império.",
                "Capítulo 2. Ao saber do decreto, Ester enfrenta uma decisão arriscada: aproximar-se do rei sem ser chamada poderia custar sua vida. Mardoqueu a desafia a considerar que sua posição talvez tivesse um propósito naquele momento. Ester pede jejum ao povo, entra na presença do rei e prepara cuidadosamente a ocasião para expor o plano de Hamã.",
                "Capítulo 3. O plano de Hamã é revelado e ele cai na própria armadilha preparada para Mardoqueu. Um novo decreto permite que os judeus se defendam. A libertação passa a ser lembrada na festa de Purim. A narrativa destaca coragem, prudência, identidade e a responsabilidade de agir quando uma posição de influência pode proteger outras pessoas."
            )
        ),
        BibleNarrative(
            "Daniel", "Daniel 1–6", listOf(
                "Capítulo 1. Daniel e outros jovens de Judá são levados para a Babilônia. Em ambiente estrangeiro, recebem novos nomes e treinamento para o serviço real. Daniel procura manter suas convicções sem agir de maneira impulsiva, negociando uma alternativa à alimentação do palácio e demonstrando que fidelidade e sabedoria podem caminhar juntas.",
                "Capítulo 2. Daniel interpreta sonhos de Nabucodonosor e reconhece que a sabedoria não é mérito apenas humano. Seus amigos Sadraque, Mesaque e Abede-Nego recusam adorar a estátua do rei e são lançados numa fornalha, mas sobrevivem. O poder imperial é confrontado repetidamente pela fidelidade de pessoas que não abandonam suas convicções.",
                "Capítulo 3. Já sob outro governo, Daniel continua ocupando posição de confiança. Adversários usam sua prática de oração para criar uma acusação legal. Daniel é lançado na cova dos leões e preservado. A história mostra constância: sua fé não aparece apenas em emergências, mas numa rotina construída durante décadas em contextos políticos diferentes."
            )
        ),
        BibleNarrative(
            "Vida de Jesus", "Mateus, Marcos, Lucas e João", listOf(
                "Capítulo 1. Os Evangelhos apresentam o nascimento de Jesus dentro da história de Israel. Seu ministério público começa com anúncio do Reino de Deus, chamado ao arrependimento e formação de discípulos. Jesus ensina em sinagogas, casas, montes e caminhos, usando parábolas e encontros pessoais para comunicar sua mensagem.",
                "Capítulo 2. Ao longo do ministério, os Evangelhos narram curas, sinais, confrontos e atos de compaixão. Jesus se aproxima de pessoas marginalizadas e questiona formas de religiosidade desligadas de justiça e misericórdia. O Sermão do Monte, as parábolas e os debates mostram uma ética centrada em amor a Deus e ao próximo.",
                "Capítulo 3. Em Jerusalém, a tensão aumenta. Jesus celebra a última ceia com os discípulos, é preso, julgado e crucificado. Os Evangelhos não tratam a cruz apenas como derrota política, mas como centro da missão de Jesus. Seus seguidores, inicialmente dispersos e assustados, enfrentam a perda e o silêncio do sábado.",
                "Capítulo 4. Os Evangelhos terminam com o anúncio da ressurreição e encontros de Jesus com seus seguidores. A experiência transforma medo em testemunho. A história então se conecta ao início de Atos, quando a missão dos discípulos deixa de ficar restrita a um pequeno grupo e passa a se expandir para outras regiões e povos."
            )
        ),
        BibleNarrative(
            "Paulo", "Atos 8–28 e cartas paulinas", listOf(
                "Capítulo 1. Paulo, inicialmente conhecido como Saulo, aparece como opositor do movimento cristão e participa de sua perseguição. A caminho de Damasco, vive uma experiência que muda sua direção. Depois de um período de aprendizagem e integração, passa de perseguidor a anunciador da fé que antes tentava combater.",
                "Capítulo 2. Em viagens missionárias, Paulo e seus companheiros atravessam cidades do Mediterrâneo, formando comunidades e enfrentando oposição, prisão e debates. Atos mostra estratégias diferentes conforme o público: sinagogas, praças, casas e centros urbanos. Suas cartas tratam de fé, ética, conflitos comunitários, esperança e organização das igrejas.",
                "Capítulo 3. Preso, Paulo usa até os processos legais como oportunidade para testemunhar. Sua viagem para Roma inclui tempestade e naufrágio. Atos termina com Paulo em Roma, ensinando sob vigilância. A narrativa deixa aberta a continuidade da missão e mostra como uma trajetória marcada por mudança pessoal se transformou numa influência duradoura no cristianismo."
            )
        )
    )

    fun encontrar(texto: String): BibleNarrative? {
        val q = texto.lowercase()
        return historias.firstOrNull { h ->
            val t = h.titulo.lowercase()
            q.contains(t) || t.split(" ").any { it.length >= 4 && q.contains(it) }
        }
    }
}
