package com.aida.assistant

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AidaReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val texto = intent.getStringExtra("text")?.trim().orEmpty()
        if (texto.isNotBlank()) {
            AidaNotifications.mostrar(context, "Lembrete da AIDA", texto, intent.getIntExtra("id", 7003))
        }
    }
}
