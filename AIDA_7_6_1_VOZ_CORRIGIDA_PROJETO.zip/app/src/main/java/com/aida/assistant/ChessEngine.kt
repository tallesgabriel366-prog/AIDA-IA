package com.aida.assistant

import kotlin.math.abs
import kotlin.random.Random

/**
 * Motor de xadrez local da AIDA.
 * Regras: movimentos legais, xeque, xeque-mate, afogamento, roque,
 * en passant, promoção automática, regra dos 50 lances e desfazer turno.
 */
class ChessEngine {
    data class Move(
        val fromRow: Int,
        val fromCol: Int,
        val toRow: Int,
        val toCol: Int,
        val promotion: Char = 'Q',
        val isCastle: Boolean = false,
        val isEnPassant: Boolean = false
    )

    enum class Winner { WHITE, BLACK, DRAW, NONE }

    data class GameResult(
        val ended: Boolean,
        val message: String = "",
        val winner: Winner = Winner.NONE,
        val checkmate: Boolean = false
    )

    private data class Snapshot(
        val board: Array<CharArray>,
        val whiteTurn: Boolean,
        val whiteKingMoved: Boolean,
        val blackKingMoved: Boolean,
        val whiteRookAMoved: Boolean,
        val whiteRookHMoved: Boolean,
        val blackRookAMoved: Boolean,
        val blackRookHMoved: Boolean,
        val enPassantRow: Int,
        val enPassantCol: Int,
        val halfMoveClock: Int,
        val fullMoveNumber: Int
    )

    private val board = Array(8) { CharArray(8) { ' ' } }
    private val history = mutableListOf<Snapshot>()

    var whiteTurn: Boolean = true
        private set

    private var whiteKingMoved = false
    private var blackKingMoved = false
    private var whiteRookAMoved = false
    private var whiteRookHMoved = false
    private var blackRookAMoved = false
    private var blackRookHMoved = false
    private var enPassantRow = -1
    private var enPassantCol = -1
    private var halfMoveClock = 0
    private var fullMoveNumber = 1

    init { reset() }

    fun reset() {
        val black = "rnbqkbnr"
        val white = "RNBQKBNR"
        for (c in 0..7) {
            board[0][c] = black[c]
            board[1][c] = 'p'
            board[6][c] = 'P'
            board[7][c] = white[c]
        }
        for (r in 2..5) for (c in 0..7) board[r][c] = ' '
        whiteTurn = true
        whiteKingMoved = false
        blackKingMoved = false
        whiteRookAMoved = false
        whiteRookHMoved = false
        blackRookAMoved = false
        blackRookHMoved = false
        enPassantRow = -1
        enPassantCol = -1
        halfMoveClock = 0
        fullMoveNumber = 1
        history.clear()
    }

    fun pieceAt(row: Int, col: Int): Char = if (row in 0..7 && col in 0..7) board[row][col] else ' '

    fun boardCopy(): Array<CharArray> = Array(8) { board[it].clone() }

    fun moveNumber(): Int = fullMoveNumber

    fun historySize(): Int = history.size

    fun canUndo(): Boolean = history.isNotEmpty()

    /**
     * Volta ao momento anterior ao último lance do jogador.
     * Depois da resposta da AIDA, desfaz dois meios-lances; se só o jogador
     * tiver jogado, desfaz apenas um.
     */
    fun undoLastTurn(): Int {
        if (history.isEmpty()) return 0
        val plies = if (whiteTurn && history.size >= 2) 2 else 1
        var undone = 0
        repeat(plies) {
            if (history.isNotEmpty()) {
                restore(history.removeAt(history.lastIndex))
                undone++
            }
        }
        return undone
    }

    fun legalMovesForSquare(row: Int, col: Int): List<Move> {
        val p = pieceAt(row, col)
        if (p == ' ') return emptyList()
        if (p.isUpperCase() != whiteTurn) return emptyList()
        return legalMoves(whiteTurn).filter { it.fromRow == row && it.fromCol == col }
    }

    fun legalMoves(white: Boolean = whiteTurn): List<Move> {
        val result = mutableListOf<Move>()
        for (r in 0..7) for (c in 0..7) {
            val p = board[r][c]
            if (p == ' ' || p.isUpperCase() != white) continue
            for (move in pseudoMovesFor(r, c, white, includeCastling = true)) {
                val snap = snapshot()
                applyMoveUnchecked(move, switchTurn = false)
                val legal = !isKingInCheck(white)
                restore(snap)
                if (legal) result += move
            }
        }
        return result
    }

    fun makeMove(move: Move): Boolean {
        val legal = legalMoves(whiteTurn).firstOrNull {
            it.fromRow == move.fromRow && it.fromCol == move.fromCol &&
                it.toRow == move.toRow && it.toCol == move.toCol &&
                it.promotion.uppercaseChar() == move.promotion.uppercaseChar()
        } ?: return false
        history += snapshot()
        applyMoveUnchecked(legal, switchTurn = true)
        return true
    }

    fun gameResult(): GameResult {
        if (halfMoveClock >= 100) {
            return GameResult(true, "Empate pela regra dos 50 lances.", Winner.DRAW)
        }
        if (isInsufficientMaterial()) {
            return GameResult(true, "Empate por material insuficiente.", Winner.DRAW)
        }

        val moves = legalMoves(whiteTurn)
        if (moves.isNotEmpty()) return GameResult(false)
        return if (isKingInCheck(whiteTurn)) {
            if (whiteTurn) {
                GameResult(true, "Xeque-mate. A AIDA venceu.", Winner.BLACK, checkmate = true)
            } else {
                GameResult(true, "Xeque-mate. Você venceu a AIDA!", Winner.WHITE, checkmate = true)
            }
        } else {
            GameResult(true, "Empate por afogamento.", Winner.DRAW)
        }
    }

    fun isCurrentSideInCheck(): Boolean = isKingInCheck(whiteTurn)

    fun kingSquare(white: Boolean): Pair<Int, Int>? {
        val king = if (white) 'K' else 'k'
        for (r in 0..7) for (c in 0..7) if (board[r][c] == king) return r to c
        return null
    }

    fun isKingInCheck(white: Boolean): Boolean {
        val square = kingSquare(white) ?: return true
        return isSquareAttacked(square.first, square.second, byWhite = !white)
    }

    fun chooseAiMove(levelIndex: Int): Move? {
        val moves = legalMoves(false)
        if (moves.isEmpty()) return null
        val level = levelIndex.coerceIn(0, 5)

        // Níveis baixos cometem erros intencionais; níveis altos analisam respostas.
        if (level == 0 && Random.nextInt(100) < 68) return moves.random()
        if (level == 1 && Random.nextInt(100) < 42) return moves.random()

        var best: Move? = null
        var bestScore = Int.MIN_VALUE
        for (move in moves.shuffled()) {
            val snap = snapshot()
            val moving = board[move.fromRow][move.fromCol]
            val capture = capturedPieceFor(move)
            applyMoveUnchecked(move, switchTurn = true)
            var score = moveHeuristic(move, moving, capture)

            if (isKingInCheck(true)) score += 38
            val result = gameResult()
            if (result.ended && result.winner == Winner.BLACK) score += 100000

            if (level >= 2 && !result.ended) {
                val replies = legalMoves(true)
                var bestWhiteReply = Int.MIN_VALUE
                val sample = if (level >= 4) replies else replies.shuffled().take(18)
                for (reply in sample) {
                    val snap2 = snapshot()
                    val moving2 = board[reply.fromRow][reply.fromCol]
                    val cap2 = capturedPieceFor(reply)
                    applyMoveUnchecked(reply, switchTurn = true)
                    var whiteScore = moveHeuristic(reply, moving2, cap2)
                    if (isKingInCheck(false)) whiteScore += 32
                    val afterWhite = gameResult()
                    if (afterWhite.ended && afterWhite.winner == Winner.WHITE) whiteScore += 100000

                    if (level >= 5 && !afterWhite.ended) {
                        val blackReplies = legalMoves(false).shuffled().take(18)
                        var bestBlack = Int.MIN_VALUE
                        for (br in blackReplies) {
                            val snap3 = snapshot()
                            val moving3 = board[br.fromRow][br.fromCol]
                            val cap3 = capturedPieceFor(br)
                            applyMoveUnchecked(br, switchTurn = true)
                            var s = moveHeuristic(br, moving3, cap3)
                            if (isKingInCheck(true)) s += 28
                            val afterBlack = gameResult()
                            if (afterBlack.ended && afterBlack.winner == Winner.BLACK) s += 100000
                            bestBlack = maxOf(bestBlack, s)
                            restore(snap3)
                        }
                        if (bestBlack != Int.MIN_VALUE) whiteScore -= bestBlack / 2
                    }

                    bestWhiteReply = maxOf(bestWhiteReply, whiteScore)
                    restore(snap2)
                }
                if (bestWhiteReply != Int.MIN_VALUE) score -= bestWhiteReply
            }

            restore(snap)
            if (score > bestScore) {
                bestScore = score
                best = move
            }
        }
        return best ?: moves.random()
    }

    fun bestHintForWhite(): Move? {
        val moves = legalMoves(true)
        if (moves.isEmpty()) return null
        return moves.maxByOrNull { scoreWhiteMove(it) }
    }

    /** Comentário curto da professora antes do lance ser aplicado. */
    fun explainWhiteMove(move: Move): String {
        val moving = pieceAt(move.fromRow, move.fromCol)
        if (!moving.isUpperCase()) return "Observe a segurança do seu rei antes de confirmar o lance."
        val captured = capturedPieceFor(move)
        val snap = snapshot()
        applyMoveUnchecked(move, switchTurn = true)
        val givesCheck = isKingInCheck(false)
        val mate = gameResult().let { it.ended && it.winner == Winner.WHITE }
        restore(snap)

        return when {
            mate -> "Excelente. Esse lance é xeque-mate."
            move.isCastle -> "Muito bom: roque feito, seu rei ficou mais protegido."
            givesCheck && captured != ' ' -> "Boa jogada: você capturou uma peça e ainda deu xeque."
            givesCheck -> "Boa iniciativa. Esse lance dá xeque e força uma resposta."
            captured != ' ' && pieceValue(captured) >= pieceValue(moving) -> "Boa captura. Você ganhou ou trocou material de forma favorável."
            moving.lowercaseChar() in setOf('n', 'b') && move.fromRow == 7 -> "Bom desenvolvimento. Colocar peças em jogo cedo ajuda bastante."
            move.toRow in 3..4 && move.toCol in 3..4 -> "Boa disputa do centro. Isso aumenta o espaço das suas peças."
            else -> teacherTip()
        }
    }

    fun moveToText(move: Move): String {
        val piece = board[move.fromRow][move.fromCol]
        if (move.isCastle) return if (move.toCol == 6) "roque pequeno" else "roque grande"
        val names = mapOf(
            'K' to "rei", 'Q' to "dama", 'R' to "torre", 'B' to "bispo", 'N' to "cavalo", 'P' to "peão",
            'k' to "rei", 'q' to "dama", 'r' to "torre", 'b' to "bispo", 'n' to "cavalo", 'p' to "peão"
        )
        val capture = capturedPieceFor(move) != ' '
        val action = if (capture) "captura em" else "para"
        return "${names[piece] ?: "peça"} ${squareName(move.fromRow, move.fromCol)} $action ${squareName(move.toRow, move.toCol)}"
    }

    fun squareName(row: Int, col: Int): String = "${('a'.code + col).toChar()}${8 - row}"

    fun teacherTip(): String {
        if (whiteTurn && isKingInCheck(true)) return "Seu rei está em xeque. Procure capturar a peça atacante, bloquear o ataque ou mover o rei."
        if (!whiteTurn && isKingInCheck(false)) return "A AIDA está em xeque. Boa! Tente manter a iniciativa sem deixar peças soltas."
        val whiteDeveloped = listOf(board[7][1], board[7][2], board[7][5], board[7][6]).count { it == ' ' }
        val centerWhite = listOf(board[3][3], board[3][4], board[4][3], board[4][4]).count { it.isUpperCase() }
        return when {
            fullMoveNumber <= 6 && whiteDeveloped < 2 -> "Dica: desenvolva cavalos e bispos antes de mover a mesma peça várias vezes."
            centerWhite == 0 -> "Dica: tente disputar o centro com peões ou peças."
            !whiteKingMoved -> "Dica: se estiver seguro, prepare o roque para proteger o rei."
            else -> "Dica: antes de cada lance, procure xeques, capturas e ameaças, nessa ordem."
        }
    }

    private fun scoreWhiteMove(move: Move): Int {
        val snap = snapshot()
        val moving = board[move.fromRow][move.fromCol]
        val capture = capturedPieceFor(move)
        applyMoveUnchecked(move, switchTurn = true)
        var score = moveHeuristic(move, moving, capture)
        if (isKingInCheck(false)) score += 40
        val result = gameResult()
        if (result.ended && result.winner == Winner.WHITE) score += 100000
        restore(snap)
        return score
    }

    private fun pseudoMovesFor(row: Int, col: Int, white: Boolean, includeCastling: Boolean): List<Move> {
        val p = board[row][col]
        if (p == ' ' || p.isUpperCase() != white) return emptyList()
        val out = mutableListOf<Move>()

        fun add(r: Int, c: Int, castle: Boolean = false, ep: Boolean = false) {
            if (r !in 0..7 || c !in 0..7) return
            val target = board[r][c]
            // Reis nunca são capturados; xeque-mate termina a partida antes disso.
            if (target.lowercaseChar() == 'k') return
            if (target == ' ' || target.isUpperCase() != white) {
                out += Move(row, col, r, c, isCastle = castle, isEnPassant = ep)
            }
        }

        fun ray(dr: Int, dc: Int) {
            var r = row + dr
            var c = col + dc
            while (r in 0..7 && c in 0..7) {
                val target = board[r][c]
                if (target == ' ') {
                    out += Move(row, col, r, c)
                } else {
                    if (target.isUpperCase() != white && target.lowercaseChar() != 'k') {
                        out += Move(row, col, r, c)
                    }
                    break
                }
                r += dr
                c += dc
            }
        }

        when (p.lowercaseChar()) {
            'p' -> {
                val dir = if (white) -1 else 1
                val start = if (white) 6 else 1
                val one = row + dir
                if (one in 0..7 && board[one][col] == ' ') {
                    add(one, col)
                    val two = row + 2 * dir
                    if (row == start && two in 0..7 && board[two][col] == ' ') add(two, col)
                }
                for (dc in intArrayOf(-1, 1)) {
                    val r = row + dir
                    val c = col + dc
                    if (r !in 0..7 || c !in 0..7) continue
                    val target = board[r][c]
                    if (target != ' ' && target.isUpperCase() != white) add(r, c)
                    if (r == enPassantRow && c == enPassantCol) add(r, c, ep = true)
                }
            }
            'n' -> for ((dr, dc) in arrayOf(-2 to -1, -2 to 1, -1 to -2, -1 to 2, 1 to -2, 1 to 2, 2 to -1, 2 to 1)) add(row + dr, col + dc)
            'b' -> { ray(-1, -1); ray(-1, 1); ray(1, -1); ray(1, 1) }
            'r' -> { ray(-1, 0); ray(1, 0); ray(0, -1); ray(0, 1) }
            'q' -> { ray(-1, -1); ray(-1, 1); ray(1, -1); ray(1, 1); ray(-1, 0); ray(1, 0); ray(0, -1); ray(0, 1) }
            'k' -> {
                for (dr in -1..1) for (dc in -1..1) if (dr != 0 || dc != 0) add(row + dr, col + dc)
                if (includeCastling && canCastle(white, kingSide = true)) out += Move(row, col, row, 6, isCastle = true)
                if (includeCastling && canCastle(white, kingSide = false)) out += Move(row, col, row, 2, isCastle = true)
            }
        }
        return out
    }

    private fun canCastle(white: Boolean, kingSide: Boolean): Boolean {
        val row = if (white) 7 else 0
        if (board[row][4] != if (white) 'K' else 'k') return false
        if ((white && whiteKingMoved) || (!white && blackKingMoved)) return false
        if (isKingInCheck(white)) return false

        val rookCol = if (kingSide) 7 else 0
        val rook = if (white) 'R' else 'r'
        if (board[row][rookCol] != rook) return false
        if (white && rookCol == 0 && whiteRookAMoved) return false
        if (white && rookCol == 7 && whiteRookHMoved) return false
        if (!white && rookCol == 0 && blackRookAMoved) return false
        if (!white && rookCol == 7 && blackRookHMoved) return false

        val emptyCols = if (kingSide) intArrayOf(5, 6) else intArrayOf(1, 2, 3)
        if (emptyCols.any { board[row][it] != ' ' }) return false
        val through = if (kingSide) intArrayOf(5, 6) else intArrayOf(3, 2)
        if (through.any { isSquareAttacked(row, it, byWhite = !white) }) return false
        return true
    }

    private fun isSquareAttacked(row: Int, col: Int, byWhite: Boolean): Boolean {
        val pawn = if (byWhite) 'P' else 'p'
        val pawnSourceRow = row + if (byWhite) 1 else -1
        for (dc in intArrayOf(-1, 1)) {
            val c = col + dc
            if (pawnSourceRow in 0..7 && c in 0..7 && board[pawnSourceRow][c] == pawn) return true
        }

        val knight = if (byWhite) 'N' else 'n'
        for ((dr, dc) in arrayOf(-2 to -1, -2 to 1, -1 to -2, -1 to 2, 1 to -2, 1 to 2, 2 to -1, 2 to 1)) {
            val r = row + dr
            val c = col + dc
            if (r in 0..7 && c in 0..7 && board[r][c] == knight) return true
        }

        val king = if (byWhite) 'K' else 'k'
        for (dr in -1..1) for (dc in -1..1) if (dr != 0 || dc != 0) {
            val r = row + dr
            val c = col + dc
            if (r in 0..7 && c in 0..7 && board[r][c] == king) return true
        }

        fun ray(dr: Int, dc: Int, allowed: Set<Char>): Boolean {
            var r = row + dr
            var c = col + dc
            while (r in 0..7 && c in 0..7) {
                val p = board[r][c]
                if (p != ' ') return p in allowed
                r += dr
                c += dc
            }
            return false
        }

        val bishop = if (byWhite) 'B' else 'b'
        val rook = if (byWhite) 'R' else 'r'
        val queen = if (byWhite) 'Q' else 'q'
        if (ray(-1, -1, setOf(bishop, queen)) || ray(-1, 1, setOf(bishop, queen)) ||
            ray(1, -1, setOf(bishop, queen)) || ray(1, 1, setOf(bishop, queen))) return true
        if (ray(-1, 0, setOf(rook, queen)) || ray(1, 0, setOf(rook, queen)) ||
            ray(0, -1, setOf(rook, queen)) || ray(0, 1, setOf(rook, queen))) return true
        return false
    }

    private fun capturedPieceFor(move: Move): Char {
        return if (move.isEnPassant) board[move.fromRow][move.toCol] else board[move.toRow][move.toCol]
    }

    private fun applyMoveUnchecked(move: Move, switchTurn: Boolean) {
        val moving = board[move.fromRow][move.fromCol]
        val captured = capturedPieceFor(move)

        when {
            moving == 'K' -> whiteKingMoved = true
            moving == 'k' -> blackKingMoved = true
            moving == 'R' && move.fromRow == 7 && move.fromCol == 0 -> whiteRookAMoved = true
            moving == 'R' && move.fromRow == 7 && move.fromCol == 7 -> whiteRookHMoved = true
            moving == 'r' && move.fromRow == 0 && move.fromCol == 0 -> blackRookAMoved = true
            moving == 'r' && move.fromRow == 0 && move.fromCol == 7 -> blackRookHMoved = true
        }
        if (move.toRow == 7 && move.toCol == 0 && captured == 'R') whiteRookAMoved = true
        if (move.toRow == 7 && move.toCol == 7 && captured == 'R') whiteRookHMoved = true
        if (move.toRow == 0 && move.toCol == 0 && captured == 'r') blackRookAMoved = true
        if (move.toRow == 0 && move.toCol == 7 && captured == 'r') blackRookHMoved = true

        board[move.toRow][move.toCol] = moving
        board[move.fromRow][move.fromCol] = ' '

        if (move.isEnPassant) board[move.fromRow][move.toCol] = ' '

        if (move.isCastle) {
            val row = move.fromRow
            if (move.toCol == 6) {
                board[row][5] = board[row][7]
                board[row][7] = ' '
            } else {
                board[row][3] = board[row][0]
                board[row][0] = ' '
            }
        }

        if (moving == 'P' && move.toRow == 0) board[move.toRow][move.toCol] = move.promotion.uppercaseChar()
        if (moving == 'p' && move.toRow == 7) board[move.toRow][move.toCol] = move.promotion.lowercaseChar()

        enPassantRow = -1
        enPassantCol = -1
        if (moving.lowercaseChar() == 'p' && abs(move.toRow - move.fromRow) == 2) {
            enPassantRow = (move.fromRow + move.toRow) / 2
            enPassantCol = move.fromCol
        }

        halfMoveClock = if (moving.lowercaseChar() == 'p' || captured != ' ') 0 else halfMoveClock + 1
        if (!whiteTurn && switchTurn) fullMoveNumber++
        if (switchTurn) whiteTurn = !whiteTurn
    }

    private fun moveHeuristic(move: Move, moving: Char, captured: Char): Int {
        var score = pieceValue(captured) * 12 - pieceValue(moving).coerceAtMost(9)
        val centerDistance = abs(3.5 - move.toRow) + abs(3.5 - move.toCol)
        score += (8 - (centerDistance * 2).toInt()).coerceAtLeast(0)
        if (move.isCastle) score += 22
        if (moving.lowercaseChar() == 'p' && (move.toRow == 0 || move.toRow == 7)) score += 80
        if (moving.lowercaseChar() in setOf('n', 'b') && move.fromRow in setOf(0, 7)) score += 10
        return score
    }

    private fun pieceValue(ch: Char): Int = when (ch.lowercaseChar()) {
        'q' -> 9
        'r' -> 5
        'b', 'n' -> 3
        'p' -> 1
        'k' -> 100
        else -> 0
    }

    private fun isInsufficientMaterial(): Boolean {
        val pieces = mutableListOf<Pair<Char, Pair<Int, Int>>>()
        for (r in 0..7) for (c in 0..7) {
            val p = board[r][c]
            if (p != ' ' && p.lowercaseChar() != 'k') pieces += p to (r to c)
        }
        if (pieces.isEmpty()) return true
        if (pieces.size == 1 && pieces[0].first.lowercaseChar() in setOf('b', 'n')) return true
        if (pieces.all { it.first.lowercaseChar() == 'b' }) {
            val colors = pieces.map { (_, square) -> (square.first + square.second) % 2 }.distinct()
            if (colors.size == 1) return true
        }
        return false
    }

    private fun snapshot(): Snapshot = Snapshot(
        board = Array(8) { board[it].clone() },
        whiteTurn = whiteTurn,
        whiteKingMoved = whiteKingMoved,
        blackKingMoved = blackKingMoved,
        whiteRookAMoved = whiteRookAMoved,
        whiteRookHMoved = whiteRookHMoved,
        blackRookAMoved = blackRookAMoved,
        blackRookHMoved = blackRookHMoved,
        enPassantRow = enPassantRow,
        enPassantCol = enPassantCol,
        halfMoveClock = halfMoveClock,
        fullMoveNumber = fullMoveNumber
    )

    private fun restore(s: Snapshot) {
        for (r in 0..7) board[r] = s.board[r].clone()
        whiteTurn = s.whiteTurn
        whiteKingMoved = s.whiteKingMoved
        blackKingMoved = s.blackKingMoved
        whiteRookAMoved = s.whiteRookAMoved
        whiteRookHMoved = s.whiteRookHMoved
        blackRookAMoved = s.blackRookAMoved
        blackRookHMoved = s.blackRookHMoved
        enPassantRow = s.enPassantRow
        enPassantCol = s.enPassantCol
        halfMoveClock = s.halfMoveClock
        fullMoveNumber = s.fullMoveNumber
    }
}
