package com.aida.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class AidaMemory(context: Context) {

    private val preferences = context.getSharedPreferences("aida_memory", Context.MODE_PRIVATE)

    fun salvarNome(nome: String) {
        preferences.edit().putString("user_name", nome.trim()).apply()
    }

    fun obterNome(): String? = preferences.getString("user_name", null)

    fun adicionarNota(texto: String) {
        val notes = carregarArray("notes")
        notes.put(texto.trim())
        while (notes.length() > MAX_NOTES) removeFirst(notes)
        salvarArray("notes", notes)
    }

    fun listarNotas(): List<String> {
        val notes = carregarArray("notes")
        return buildList {
            for (index in 0 until notes.length()) {
                notes.optString(index).takeIf { it.isNotBlank() }?.let(::add)
            }
        }
    }

    fun limparNotas() {
        preferences.edit().remove("notes").apply()
    }

    fun adicionarTarefa(texto: String) {
        val tasks = carregarArray("tasks")
        tasks.put(JSONObject().put("text", texto.trim()).put("done", false))
        salvarArray("tasks", tasks)
    }

    fun listarTarefas(): List<Pair<String, Boolean>> {
        val tasks = carregarArray("tasks")
        return buildList {
            for (index in 0 until tasks.length()) {
                val task = tasks.optJSONObject(index) ?: continue
                add(task.optString("text") to task.optBoolean("done"))
            }
        }
    }

    fun concluirTarefa(numero: Int): Boolean {
        val tasks = carregarArray("tasks")
        if (numero !in 1..tasks.length()) return false
        tasks.optJSONObject(numero - 1)?.put("done", true) ?: return false
        salvarArray("tasks", tasks)
        return true
    }

    fun limparTarefas() = preferences.edit().remove("tasks").apply()

    fun salvarPersonalidade(estilo: String) = preferences.edit().putString("personality", estilo).apply()

    fun obterPersonalidade(): String = preferences.getString("personality", "amigável") ?: "amigável"

    fun salvarTema(tema: String) = preferences.edit().putString("theme", tema).apply()

    fun obterTema(): String = preferences.getString("theme", "roxo") ?: "roxo"

    fun contextoRecente(): String {
        val history = carregarArray("history")
        val start = (history.length() - 8).coerceAtLeast(0)
        return buildString {
            for (index in start until history.length()) {
                val item = history.optJSONObject(index) ?: continue
                append(if (item.optString("role") == "user") "Usuário" else "AIDA")
                append(": ").append(item.optString("text")).append('\n')
            }
        }.trim()
    }

    fun historicoParaIA(perguntaAtual: String, limite: Int = 6): List<Pair<String, String>> {
        val history = carregarArray("history")
        var endExclusive = history.length()
        if (endExclusive > 0) {
            val last = history.optJSONObject(endExclusive - 1)
            if (last?.optString("role") == "user" &&
                last.optString("text").trim().equals(perguntaAtual.trim(), ignoreCase = true)
            ) {
                endExclusive--
            }
        }
        val start = (endExclusive - limite.coerceIn(0, 10)).coerceAtLeast(0)
        return buildList {
            for (index in start until endExclusive) {
                val item = history.optJSONObject(index) ?: continue
                val role = item.optString("role")
                val text = item.optString("text").trim()
                if (text.isNotBlank() && (role == "user" || role == "assistant")) add(role to text)
            }
        }
    }

    fun adicionarDiario(texto: String) {
        val entries = carregarArray("diary")
        entries.put(JSONObject().put("text", texto.trim()).put("time", System.currentTimeMillis()))
        while (entries.length() > 50) removeFirst(entries)
        salvarArray("diary", entries)
    }

    fun listarDiario(): List<String> {
        val entries = carregarArray("diary")
        return buildList {
            for (index in 0 until entries.length()) {
                entries.optJSONObject(index)?.optString("text")?.takeIf { it.isNotBlank() }?.let(::add)
            }
        }
    }

    fun limparDiario() = preferences.edit().remove("diary").apply()

    fun salvarComandoPersonalizado(frase: String, resposta: String) {
        val commands = runCatching { JSONObject(preferences.getString("custom_commands", "{}").orEmpty()) }
            .getOrDefault(JSONObject())
        commands.put(frase.trim().lowercase(), resposta.trim())
        preferences.edit().putString("custom_commands", commands.toString()).apply()
    }

    fun respostaPersonalizada(frase: String): String? = runCatching {
        JSONObject(preferences.getString("custom_commands", "{}").orEmpty())
            .optString(frase.trim().lowercase()).takeIf { it.isNotBlank() }
    }.getOrNull()

    fun listarComandosPersonalizados(): List<String> = runCatching {
        val commands = JSONObject(preferences.getString("custom_commands", "{}").orEmpty())
        buildList {
            val keys = commands.keys()
            while (keys.hasNext()) add(keys.next())
        }
    }.getOrDefault(emptyList())

    fun definirModoBiblico(ativo: Boolean) {
        preferences.edit().putBoolean("bible_mode", ativo).apply()
    }

    fun modoBiblicoAtivo(): Boolean = preferences.getBoolean("bible_mode", false)

    fun salvarModoBiblicoDetalhe(modo: String) {
        preferences.edit().putString("bible_detail_mode", modo.trim().lowercase()).apply()
    }

    fun obterModoBiblicoDetalhe(): String =
        preferences.getString("bible_detail_mode", "estudo") ?: "estudo"

    fun proximoIndiceQuiz(total: Int): Int {
        if (total <= 0) return 0
        val usadosArray = carregarArray("quiz_used")
        val usados = mutableSetOf<Int>()
        for (index in 0 until usadosArray.length()) {
            val value = usadosArray.optInt(index, -1)
            if (value in 0 until total) usados += value
        }
        if (usados.size >= total) usados.clear()
        val disponiveis = (0 until total).filterNot { it in usados }
        val escolhido = disponiveis.random()
        usados += escolhido
        salvarArray("quiz_used", JSONArray().apply { usados.forEach { put(it) } })
        return escolhido
    }

    fun reiniciarQuiz() {
        preferences.edit().remove("quiz_used").apply()
    }

    fun indiceVersiculoDoDia(total: Int): Int {
        if (total <= 0) return 0
        val day = System.currentTimeMillis() / 86_400_000L
        val savedDay = preferences.getLong("verse_day", -1L)
        val savedIndex = preferences.getInt("verse_index", -1)
        if (savedDay == day && savedIndex in 0 until total) return savedIndex

        val usedArray = carregarArray("used_verses")
        val used = mutableSetOf<Int>()
        for (index in 0 until usedArray.length()) used.add(usedArray.optInt(index, -1))
        var available = (0 until total).filterNot { it in used }
        if (available.isEmpty()) {
            used.clear()
            available = (0 until total).toList()
        }
        val selected = available[(day % available.size).toInt()]
        used.add(selected)
        salvarArray("used_verses", JSONArray().apply { used.forEach { put(it) } })
        preferences.edit().putLong("verse_day", day).putInt("verse_index", selected).apply()
        return selected
    }

    fun deveAnunciarVersiculoHoje(): Boolean {
        val day = System.currentTimeMillis() / 86_400_000L
        if (preferences.getLong("verse_announced_day", -1L) == day) return false
        preferences.edit().putLong("verse_announced_day", day).apply()
        return true
    }

    fun salvarVelocidadeVoz(value: Float) = preferences.edit().putFloat("voice_speed", value).apply()
    fun obterVelocidadeVoz(): Float = preferences.getFloat("voice_speed", 1.05f)

    fun aplicarPadraoVozRapidaSeNecessario() {
        if (preferences.getBoolean("voice_703_migrated", false)) return
        if (!preferences.contains("voice_speed") || kotlin.math.abs(obterVelocidadeVoz() - 0.92f) < 0.001f) {
            preferences.edit().putFloat("voice_speed", 1.05f).apply()
        }
        preferences.edit().putBoolean("voice_703_migrated", true).apply()
    }
    fun salvarTomVoz(value: Float) = preferences.edit().putFloat("voice_pitch", value).apply()
    fun obterTomVoz(): Float = preferences.getFloat("voice_pitch", 1.02f)

    fun salvarChaveGemini(chave: String) {
        preferences.edit().putString("gemini_api_key", chave.trim()).apply()
    }

    fun obterChaveGemini(): String = preferences.getString("gemini_api_key", "")?.trim().orEmpty()

    fun apagarChaveGemini() {
        preferences.edit().remove("gemini_api_key").apply()
    }

    fun adicionarHistorico(papel: String, texto: String) {
        val history = carregarArray("history")
        history.put(
            JSONObject()
                .put("role", papel)
                .put("text", texto.trim())
                .put("time", System.currentTimeMillis())
        )
        while (history.length() > MAX_HISTORY) removeFirst(history)
        salvarArray("history", history)
    }

    fun historicoFormatado(): String {
        val history = carregarArray("history")
        if (history.length() == 0) return "O histórico ainda está vazio."

        return buildString {
            for (index in 0 until history.length()) {
                val item = history.optJSONObject(index) ?: continue
                val autor = if (item.optString("role") == "user") "Você" else "AIDA"
                append(autor)
                append(": ")
                append(item.optString("text"))
                if (index < history.length() - 1) append("\n\n")
            }
        }
    }

    fun limparHistorico() {
        preferences.edit().remove("history").apply()
    }

    fun adicionarMemoriaPessoal(texto: String) {
        val value = texto.trim()
        if (value.isBlank()) return
        val items = carregarArray("personal_facts")
        val normalized = value.lowercase()
        for (i in 0 until items.length()) {
            if (items.optString(i).trim().lowercase() == normalized) return
        }
        items.put(value)
        while (items.length() > MAX_PERSONAL_FACTS) removeFirst(items)
        salvarArray("personal_facts", items)
    }

    fun listarMemoriasPessoais(): List<String> {
        val items = carregarArray("personal_facts")
        return buildList {
            for (i in 0 until items.length()) {
                items.optString(i).takeIf { it.isNotBlank() }?.let(::add)
            }
        }
    }

    fun removerMemoriaPessoal(trecho: String): Boolean {
        val alvo = trecho.trim().lowercase()
        if (alvo.isBlank()) return false
        val items = carregarArray("personal_facts")
        var removed = false
        val updated = JSONArray()
        for (i in 0 until items.length()) {
            val value = items.optString(i)
            if (!removed && value.lowercase().contains(alvo)) removed = true else updated.put(value)
        }
        if (removed) salvarArray("personal_facts", updated)
        return removed
    }

    fun adicionarFavorito(texto: String) {
        val value = texto.trim()
        if (value.isBlank()) return
        val items = carregarArray("favorites")
        items.put(JSONObject().put("text", value).put("time", System.currentTimeMillis()))
        while (items.length() > MAX_FAVORITES) removeFirst(items)
        salvarArray("favorites", items)
    }

    fun listarFavoritos(): List<String> {
        val items = carregarArray("favorites")
        return buildList {
            for (i in 0 until items.length()) {
                items.optJSONObject(i)?.optString("text")?.takeIf { it.isNotBlank() }?.let(::add)
            }
        }
    }

    fun limparFavoritos() = preferences.edit().remove("favorites").apply()

    fun salvarAtalhoPersonalizado(nome: String, comando: String) {
        val atalhos = runCatching { JSONObject(preferences.getString("custom_shortcuts", "{}").orEmpty()) }
            .getOrDefault(JSONObject())
        atalhos.put(nome.trim().lowercase(), comando.trim())
        preferences.edit().putString("custom_shortcuts", atalhos.toString()).apply()
    }

    fun obterAtalhoPersonalizado(nome: String): String? = runCatching {
        JSONObject(preferences.getString("custom_shortcuts", "{}").orEmpty())
            .optString(nome.trim().lowercase()).takeIf { it.isNotBlank() }
    }.getOrNull()

    fun listarAtalhosPersonalizados(): List<Pair<String, String>> = runCatching {
        val obj = JSONObject(preferences.getString("custom_shortcuts", "{}").orEmpty())
        buildList {
            val keys = obj.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                add(key to obj.optString(key))
            }
        }
    }.getOrDefault(emptyList())

    fun salvarRotinaPersonalizada(nome: String, comandos: List<String>) {
        val obj = runCatching { JSONObject(preferences.getString("custom_routines", "{}").orEmpty()) }.getOrDefault(JSONObject())
        val array = JSONArray()
        comandos.map { it.trim() }.filter { it.isNotBlank() }.take(10).forEach(array::put)
        obj.put(nome.trim().lowercase(), array)
        preferences.edit().putString("custom_routines", obj.toString()).apply()
    }

    fun obterRotinaPersonalizada(nome: String): List<String>? = runCatching {
        val obj = JSONObject(preferences.getString("custom_routines", "{}").orEmpty())
        val array = obj.optJSONArray(nome.trim().lowercase()) ?: return@runCatching null
        buildList {
            for (i in 0 until array.length()) array.optString(i).takeIf { it.isNotBlank() }?.let(::add)
        }.takeIf { it.isNotEmpty() }
    }.getOrNull()

    fun listarRotinasPersonalizadas(): List<Pair<String, List<String>>> = runCatching {
        val obj = JSONObject(preferences.getString("custom_routines", "{}").orEmpty())
        buildList {
            val keys = obj.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val array = obj.optJSONArray(key) ?: continue
                val comandos = buildList {
                    for (i in 0 until array.length()) array.optString(i).takeIf { it.isNotBlank() }?.let(::add)
                }
                add(key to comandos)
            }
        }
    }.getOrDefault(emptyList())

    fun salvarConversaContinua(ativa: Boolean) = preferences.edit().putBoolean("continuous_conversation", ativa).apply()
    fun conversaContinuaAtiva(): Boolean = preferences.getBoolean("continuous_conversation", false)

    fun salvarWakeWord(ativa: Boolean) = preferences.edit().putBoolean("wake_word_enabled", ativa).apply()
    fun wakeWordAtiva(): Boolean = preferences.getBoolean("wake_word_enabled", false)

    fun salvarMateriaProfessor(materia: String) = preferences.edit().putString("teacher_subject", materia.trim()).apply()
    fun obterMateriaProfessor(): String = preferences.getString("teacher_subject", "geral") ?: "geral"
    fun salvarNivelProfessor(nivel: String) = preferences.edit().putString("teacher_level", nivel.trim()).apply()
    fun obterNivelProfessor(): String = preferences.getString("teacher_level", "intermediário") ?: "intermediário"

    fun salvarFiltroQuiz(categoria: String, dificuldade: String) {
        val old = obterCategoriaQuiz() + "|" + obterDificuldadeQuiz()
        val novo = categoria + "|" + dificuldade
        preferences.edit()
            .putString("quiz_category", categoria)
            .putString("quiz_difficulty", dificuldade)
            .apply()
        if (old != novo) reiniciarQuiz()
    }
    fun obterCategoriaQuiz(): String = preferences.getString("quiz_category", "todas") ?: "todas"
    fun obterDificuldadeQuiz(): String = preferences.getString("quiz_difficulty", "todas") ?: "todas"

    fun registrarResultadoQuiz(correto: Boolean): QuizStats {
        val total = preferences.getInt("quiz_total", 0) + 1
        val acertos = preferences.getInt("quiz_correct", 0) + if (correto) 1 else 0
        val streakAtual = if (correto) preferences.getInt("quiz_streak", 0) + 1 else 0
        val recorde = maxOf(preferences.getInt("quiz_best_streak", 0), streakAtual)
        val xp = preferences.getInt("quiz_xp", 0) + if (correto) 10 + minOf(streakAtual, 10) else 2
        preferences.edit()
            .putInt("quiz_total", total)
            .putInt("quiz_correct", acertos)
            .putInt("quiz_streak", streakAtual)
            .putInt("quiz_best_streak", recorde)
            .putInt("quiz_xp", xp)
            .apply()
        return QuizStats(total, acertos, streakAtual, recorde, xp)
    }

    fun obterEstatisticasQuiz(): QuizStats = QuizStats(
        total = preferences.getInt("quiz_total", 0),
        acertos = preferences.getInt("quiz_correct", 0),
        sequencia = preferences.getInt("quiz_streak", 0),
        melhorSequencia = preferences.getInt("quiz_best_streak", 0),
        xp = preferences.getInt("quiz_xp", 0)
    )

    fun resetarEstatisticasQuiz() {
        preferences.edit()
            .remove("quiz_total").remove("quiz_correct").remove("quiz_streak")
            .remove("quiz_best_streak").remove("quiz_xp").apply()
    }

    fun definirModulo(chave: String, ativo: Boolean) =
        preferences.edit().putBoolean("module_${chave.trim().lowercase()}", ativo).apply()

    fun moduloAtivo(chave: String): Boolean =
        preferences.getBoolean("module_${chave.trim().lowercase()}", true)

    fun modulos(): Map<String, Boolean> = MODULOS.associateWith(::moduloAtivo)

    fun limparTudo() {
        val geminiKey = obterChaveGemini()
        preferences.edit().clear().apply()
        if (geminiKey.isNotBlank()) salvarChaveGemini(geminiKey)
    }

    private fun carregarArray(key: String): JSONArray = runCatching {
        JSONArray(preferences.getString(key, "[]").orEmpty())
    }.getOrDefault(JSONArray())

    private fun salvarArray(key: String, array: JSONArray) {
        preferences.edit().putString(key, array.toString()).apply()
    }

    private fun removeFirst(source: JSONArray) {
        val updated = JSONArray()
        for (index in 1 until source.length()) updated.put(source.get(index))
        while (source.length() > 0) source.remove(source.length() - 1)
        for (index in 0 until updated.length()) source.put(updated.get(index))
    }

    data class QuizStats(
        val total: Int,
        val acertos: Int,
        val sequencia: Int,
        val melhorSequencia: Int,
        val xp: Int
    )

    companion object {
        val MODULOS = listOf("ia", "voz", "jogos", "biblia", "notificacoes", "camera", "internet", "automacao", "memoria")
        private const val MAX_NOTES = 20
        private const val MAX_HISTORY = 60
        private const val MAX_PERSONAL_FACTS = 40
        private const val MAX_FAVORITES = 30
    }
}
