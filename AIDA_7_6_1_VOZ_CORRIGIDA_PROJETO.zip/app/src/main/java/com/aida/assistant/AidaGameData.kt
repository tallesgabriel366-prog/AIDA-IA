package com.aida.assistant

object AidaGameData {
    val forca = listOf(
        "android", "kotlin", "tecnologia", "galaxia", "computador", "internet", "algoritmo",
        "brasil", "historia", "matematica", "planeta", "energia", "musica", "amizade", "sabedoria"
    )

    data class QuemSouEu(val resposta: String, val dicas: List<String>)
    val quemSouEu = listOf(
        QuemSouEu("Albert Einstein", listOf("Fui físico.", "Meu nome é ligado à relatividade.", "Nasci na Alemanha.")),
        QuemSouEu("Pelé", listOf("Fui jogador de futebol.", "Sou brasileiro.", "Fiquei conhecido como Rei do Futebol.")),
        QuemSouEu("Moisés", listOf("Sou personagem bíblico.", "Minha história envolve o Egito.", "Liderei o êxodo.")),
        QuemSouEu("Ada Lovelace", listOf("Vivi no século dezenove.", "Trabalhei com ideias de máquinas de cálculo.", "Sou lembrada como pioneira da programação.")),
        QuemSouEu("Santos Dumont", listOf("Sou brasileiro.", "Trabalhei com aviação.", "Meu nome é associado ao 14-bis.")),
        QuemSouEu("Marie Curie", listOf("Fui cientista.", "Pesquisei radioatividade.", "Recebi dois prêmios Nobel em áreas científicas diferentes."))
    )

    val verdade = listOf(
        "Qual habilidade você mais gostaria de aprender este ano?",
        "Qual foi uma coisa simples que te deixou feliz recentemente?",
        "Qual matéria você acha mais difícil hoje?",
        "Qual lugar você gostaria de conhecer?",
        "Qual música você consegue ouvir várias vezes sem cansar?",
        "Qual hábito você gostaria de melhorar?"
    )

    val desafio = listOf(
        "Faça dez segundos de alongamento.",
        "Diga três coisas pelas quais você é grato hoje.",
        "Organize cinco itens próximos de você.",
        "Tente falar o alfabeto de trás para frente até onde conseguir.",
        "Faça uma conta de cabeça: dezessete vezes quatro.",
        "Escolha uma tarefa pequena e conclua nos próximos cinco minutos."
    )

    val memoriaPalavras = listOf(
        listOf("lua", "café", "ponte", "verde", "livro"),
        listOf("avião", "chuva", "janela", "fogo", "caneta"),
        listOf("gato", "azul", "praia", "chave", "estrela"),
        listOf("música", "rio", "relógio", "flor", "nuvem")
    )
}
