package com.aida.assistant

import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class AiClient(
    private val backendEndpoint: String,
    private val geminiKey: () -> String
) {
    private val mainHandler = Handler(Looper.getMainLooper())

    @Volatile
    private var ultimoErroApi: String? = null

    @Volatile
    private var modelosCacheKey: String? = null

    @Volatile
    private var modelosCache: List<String> = emptyList()

    fun perguntar(
        mensagem: String,
        instrucoesSistema: String,
        historico: List<Pair<String, String>> = emptyList(),
        callback: (String?) -> Unit
    ) {
        executar(callback) {
            val key = geminiKey()
            when {
                key.isNotBlank() -> enviarGemini(mensagem, null, key, instrucoesSistema, historico)
                backendValido() -> enviarBackend(
                    backendEndpoint,
                    JSONObject()
                        .put("message", mensagem)
                        .put("system_instructions", instrucoesSistema)
                        .put("history", historicoJson(historico))
                )
                else -> {
                    ultimoErroApi = "A chave da API não está configurada."
                    null
                }
            }
        }
    }

    fun perguntarStreaming(
        mensagem: String,
        instrucoesSistema: String,
        historico: List<Pair<String, String>> = emptyList(),
        onChunk: (String) -> Unit,
        onComplete: (String?) -> Unit
    ) {
        Thread {
            var respostaFinal: String? = null
            try {
                val key = geminiKey()
                respostaFinal = when {
                    key.isNotBlank() -> enviarGeminiStreaming(
                        mensagem,
                        key,
                        instrucoesSistema,
                        historico
                    ) { chunk ->
                        mainHandler.post { onChunk(chunk) }
                    }
                    backendValido() -> enviarBackend(
                        backendEndpoint,
                        JSONObject()
                            .put("message", mensagem)
                            .put("system_instructions", instrucoesSistema)
                            .put("history", historicoJson(historico))
                    )?.also { full -> mainHandler.post { onChunk(full) } }
                    else -> {
                        ultimoErroApi = "A chave da API não está configurada."
                        null
                    }
                }
                if (!respostaFinal.isNullOrBlank()) ultimoErroApi = null
            } catch (error: Exception) {
                ultimoErroApi = error.message ?: error.javaClass.simpleName
            }
            mainHandler.post { onComplete(respostaFinal) }
        }.start()
    }

    fun analisarImagem(
        imageBase64: String,
        prompt: String = "Analise esta imagem. Descreva o que aparece e destaque o que for útil ao usuário.",
        callback: (String?) -> Unit
    ) {
        executar(callback) {
            val key = geminiKey()
            val instructions = """
                Você é AIDA, a assistente virtual por voz deste aplicativo Android.
                Responda sempre em português do Brasil. Analise somente a imagem atual.
                Seja clara, útil e objetiva. Não diga que é Gemini nem que é o Google.
            """.trimIndent()
            when {
                key.isNotBlank() -> enviarGemini(
                    prompt,
                    imageBase64,
                    key,
                    instructions,
                    emptyList()
                )
                backendValido() -> {
                    val endpoint = backendEndpoint.substringBeforeLast('/', backendEndpoint) + "/vision"
                    enviarBackend(
                        endpoint,
                        JSONObject()
                            .put("image", "data:image/jpeg;base64,$imageBase64")
                            .put("system_instructions", instructions)
                    )
                }
                else -> {
                    ultimoErroApi = "A chave da API não está configurada."
                    null
                }
            }
        }
    }

    fun testarConexao(callback: (Boolean, String) -> Unit) {
        val key = geminiKey()
        if (key.isBlank()) {
            callback(false, "Cole e salve sua chave gratuita primeiro.")
            return
        }
        Thread {
            val result = runCatching {
                enviarGemini(
                    "Responda somente: AIDA conectada.",
                    null,
                    key,
                    "Você é AIDA, a assistente virtual deste aplicativo Android. Responda em português do Brasil.",
                    emptyList()
                )
            }
            mainHandler.post {
                val resposta = result.getOrNull()
                if (!resposta.isNullOrBlank()) {
                    ultimoErroApi = null
                    callback(true, "IA conectada com sucesso.")
                } else {
                    val detalhe = erroAmigavel(result.exceptionOrNull()?.message ?: ultimoErroApi)
                    callback(false, detalhe ?: "A chave não foi aceita ou a internet falhou.")
                }
            }
        }.start()
    }

    fun ultimoErroAmigavel(): String? = erroAmigavel(ultimoErroApi)

    fun erroIndicaCredencialInvalida(): Boolean {
        val erro = ultimoErroApi.orEmpty()
        return erro.contains("Erro 401") || erro.contains("Erro 403") ||
            erro.contains("API key not valid", ignoreCase = true)
    }

    private fun executar(callback: (String?) -> Unit, block: () -> String?) {
        Thread {
            val resposta = try {
                block().also {
                    if (!it.isNullOrBlank()) ultimoErroApi = null
                }
            } catch (error: Exception) {
                ultimoErroApi = error.message ?: error.javaClass.simpleName
                null
            }
            mainHandler.post { callback(resposta) }
        }.start()
    }

    private fun backendValido(): Boolean = backendEndpoint.isNotBlank() && !backendEndpoint.contains("10.0.2.2")

    private fun historicoJson(historico: List<Pair<String, String>>): JSONArray = JSONArray().apply {
        historico.forEach { (role, text) ->
            put(JSONObject().put("role", role).put("text", text))
        }
    }

    /**
     * O REST do Gemini exige que o histórico de chat alterne entre user/model.
     * A AIDA também salva falas locais e espontâneas no histórico, então removemos
     * falas de modelo antes do primeiro usuário e juntamos turnos consecutivos do
     * mesmo papel. Isso impede o caso em que o teste da chave funciona, mas uma
     * pergunta real falha com HTTP 400 por histórico inválido.
     */
    private fun normalizarHistorico(historico: List<Pair<String, String>>): MutableList<Pair<String, String>> {
        val normalizado = mutableListOf<Pair<String, String>>()
        historico.takeLast(10).forEach { (roleOriginal, textOriginal) ->
            val text = textOriginal.trim()
            if (text.isBlank()) return@forEach
            val role = if (roleOriginal == "assistant" || roleOriginal == "model") "model" else "user"

            // Um chat válido deve começar com uma mensagem do usuário.
            if (normalizado.isEmpty() && role == "model") return@forEach

            if (normalizado.lastOrNull()?.first == role) {
                val anterior = normalizado.removeAt(normalizado.lastIndex)
                normalizado += role to (anterior.second + "\n\n" + text)
            } else {
                normalizado += role to text
            }
        }
        return normalizado
    }

    private fun criarPayloadGemini(
        texto: String,
        imageBase64: String?,
        instrucoesSistema: String,
        historico: List<Pair<String, String>>
    ): JSONObject {
        val contents = JSONArray()
        val normalizado = normalizarHistorico(historico)

        normalizado.forEach { (role, text) ->
            contents.put(
                JSONObject()
                    .put("role", role)
                    .put("parts", JSONArray().put(JSONObject().put("text", text)))
            )
        }

        val currentParts = JSONArray().put(JSONObject().put("text", texto))
        if (!imageBase64.isNullOrBlank()) {
            currentParts.put(
                JSONObject().put(
                    "inlineData",
                    JSONObject().put("mimeType", "image/jpeg").put("data", imageBase64)
                )
            )
        }

        // Se o histórico terminou em user, una a pergunta atual a esse turno para
        // manter a alternância exigida pela API.
        if (normalizado.lastOrNull()?.first == "user" && imageBase64.isNullOrBlank()) {
            val ultimo = contents.optJSONObject(contents.length() - 1)
            val parts = ultimo?.optJSONArray("parts")
            val textoAnterior = parts?.optJSONObject(0)?.optString("text").orEmpty()
            if (parts != null) {
                parts.put(0, JSONObject().put("text", "$textoAnterior\n\nNova mensagem: $texto"))
            }
        } else {
            contents.put(JSONObject().put("role", "user").put("parts", currentParts))
        }

        return JSONObject()
            .put("contents", contents)
            .put(
                "generationConfig",
                JSONObject().put("maxOutputTokens", 1100)
            )
            .also { payload ->
                if (instrucoesSistema.isNotBlank()) {
                    payload.put(
                        "systemInstruction",
                        JSONObject().put(
                            "parts",
                            JSONArray().put(JSONObject().put("text", instrucoesSistema))
                        )
                    )
                }
            }
    }

    private fun enviarGeminiStreaming(
        texto: String,
        key: String,
        instrucoesSistema: String,
        historico: List<Pair<String, String>>,
        onChunk: (String) -> Unit
    ): String? {
        var ultimoErro: Exception? = null

        for (model in modelosParaChave(key)) {
            val tentativas = if (historico.isEmpty()) listOf(historico) else listOf(historico, emptyList())
            for ((indice, historicoTentativa) in tentativas.withIndex()) {
                try {
                    val payload = criarPayloadGemini(texto, null, instrucoesSistema, historicoTentativa)
                    val target = "https://generativelanguage.googleapis.com/v1beta/models/$model:streamGenerateContent?alt=sse"
                    val resposta = enviarJsonSse(
                        target,
                        payload,
                        mapOf("x-goog-api-key" to key),
                        onChunk
                    )
                    if (!resposta.isNullOrBlank()) {
                        ultimoErroApi = null
                        return resposta
                    }
                } catch (error: Exception) {
                    ultimoErro = error
                    ultimoErroApi = error.message ?: error.javaClass.simpleName
                    val credencialInvalida = error.message?.contains("Erro 401") == true ||
                        error.message?.contains("Erro 403") == true
                    if (credencialInvalida) throw error
                    val deveTentarSemHistorico = indice == 0 && historico.isNotEmpty() &&
                        error.message?.contains("Erro 400") == true
                    if (deveTentarSemHistorico) continue
                    break
                }
            }
        }

        // Algumas chaves/projetos podem aceitar generateContent, mas devolver 404
        // no endpoint de streaming para o modelo escolhido. Nesse caso, a AIDA
        // cai automaticamente para a chamada normal em vez de ficar offline.
        if (ultimoErro?.message?.contains("Erro 404") == true) {
            val respostaNormal = enviarGemini(texto, null, key, instrucoesSistema, historico)
            if (!respostaNormal.isNullOrBlank()) {
                onChunk(respostaNormal)
                ultimoErroApi = null
                return respostaNormal
            }
        }

        throw ultimoErro ?: IllegalStateException("Não foi possível acessar o streaming do Gemini.")
    }

    private fun enviarGemini(
        texto: String,
        imageBase64: String?,
        key: String,
        instrucoesSistema: String,
        historico: List<Pair<String, String>>
    ): String? {
        var ultimoErro: Exception? = null

        for (model in modelosParaChave(key)) {
            val tentativas = if (historico.isEmpty()) listOf(historico) else listOf(historico, emptyList())
            for ((indice, historicoTentativa) in tentativas.withIndex()) {
                try {
                    val payload = criarPayloadGemini(texto, imageBase64, instrucoesSistema, historicoTentativa)
                    val target = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"
                    val resposta = enviarJson(target, payload, mapOf("x-goog-api-key" to key)) { response ->
                        val responseParts = response.optJSONArray("candidates")
                            ?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                        buildString {
                            if (responseParts != null) {
                                for (partIndex in 0 until responseParts.length()) {
                                    responseParts.optJSONObject(partIndex)?.optString("text")
                                        ?.takeIf { it.isNotBlank() }?.let(::append)
                                }
                            }
                        }.trim().takeIf { it.isNotBlank() }
                    }
                    if (!resposta.isNullOrBlank()) {
                        ultimoErroApi = null
                        return resposta
                    }
                } catch (error: Exception) {
                    ultimoErro = error
                    ultimoErroApi = error.message ?: error.javaClass.simpleName

                    val credencialInvalida = error.message?.contains("Erro 401") == true ||
                        error.message?.contains("Erro 403") == true
                    if (credencialInvalida) throw error

                    // A segunda tentativa do mesmo modelo já é sem histórico.
                    // Se a primeira falhar por um 400 de histórico, fazemos o retry limpo.
                    val deveTentarSemHistorico = indice == 0 && historico.isNotEmpty() &&
                        error.message?.contains("Erro 400") == true
                    if (deveTentarSemHistorico) continue
                    break
                }
            }
        }
        throw ultimoErro ?: IllegalStateException("Não foi possível acessar o Gemini.")
    }

    /**
     * Consulta /v1beta/models para usar somente modelos que a chave atual realmente
     * consegue enxergar e que anunciam suporte a generateContent. Isso evita 404
     * causado por diferenças de disponibilidade entre projetos/chaves.
     */
    private fun modelosParaChave(key: String): List<String> {
        if (modelosCacheKey == key && modelosCache.isNotEmpty()) return modelosCache

        val disponiveis = runCatching {
            val connection = (URL("https://generativelanguage.googleapis.com/v1beta/models").openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 8_000
                readTimeout = 12_000
                setRequestProperty("Accept", "application/json")
                setRequestProperty("x-goog-api-key", key)
            }
            try {
                val code = connection.responseCode
                if (code !in 200..299) return@runCatching emptySet<String>()
                val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                val models = JSONObject(body).optJSONArray("models") ?: return@runCatching emptySet<String>()
                buildSet {
                    for (i in 0 until models.length()) {
                        val item = models.optJSONObject(i) ?: continue
                        val methods = item.optJSONArray("supportedGenerationMethods")
                        var supportsGenerate = false
                        if (methods != null) {
                            for (j in 0 until methods.length()) {
                                if (methods.optString(j) == "generateContent") {
                                    supportsGenerate = true
                                    break
                                }
                            }
                        }
                        if (supportsGenerate) {
                            item.optString("name")
                                .removePrefix("models/")
                                .takeIf { it.startsWith("gemini-") }
                                ?.let(::add)
                        }
                    }
                }
            } finally {
                connection.disconnect()
            }
        }.getOrDefault(emptySet())

        val escolhidos = if (disponiveis.isEmpty()) {
            GEMINI_MODELS
        } else {
            val preferidos = GEMINI_MODELS.filter { it in disponiveis }
            val outrosFlash = disponiveis
                .filter { "flash" in it && "tts" !in it && "live" !in it && "image" !in it }
                .sortedDescending()
            (preferidos + outrosFlash).distinct().take(8).ifEmpty { GEMINI_MODELS }
        }

        modelosCacheKey = key
        modelosCache = escolhidos
        return escolhidos
    }

    private fun enviarJsonSse(
        target: String,
        payload: JSONObject,
        headers: Map<String, String>,
        onChunk: (String) -> Unit
    ): String? {
        val connection = (URL(target).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 10_000
            readTimeout = 45_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "text/event-stream")
            headers.forEach { (name, value) -> setRequestProperty(name, value) }
        }
        return try {
            connection.outputStream.bufferedWriter(Charsets.UTF_8).use { it.write(payload.toString()) }
            val code = connection.responseCode
            if (code !in 200..299) {
                val responseText = connection.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                val message = runCatching {
                    JSONObject(responseText).optJSONObject("error")?.optString("message")
                }.getOrNull().orEmpty()
                throw IllegalStateException("Erro $code${if (message.isNotBlank()) ": $message" else ""}")
            }

            val full = StringBuilder()
            connection.inputStream.bufferedReader(Charsets.UTF_8).useLines { lines ->
                lines.forEach { rawLine ->
                    if (!rawLine.startsWith("data:")) return@forEach
                    val data = rawLine.removePrefix("data:").trim()
                    if (data.isBlank() || data == "[DONE]") return@forEach
                    val chunk = runCatching {
                        val response = JSONObject(data)
                        val parts = response.optJSONArray("candidates")
                            ?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                        buildString {
                            if (parts != null) {
                                for (i in 0 until parts.length()) {
                                    parts.optJSONObject(i)?.optString("text")
                                        ?.takeIf { it.isNotEmpty() }?.let(::append)
                                }
                            }
                        }
                    }.getOrDefault("")
                    if (chunk.isNotEmpty()) {
                        full.append(chunk)
                        onChunk(chunk)
                    }
                }
            }
            full.toString().trim().takeIf { it.isNotBlank() }
        } finally {
            connection.disconnect()
        }
    }

    private fun enviarBackend(target: String, payload: JSONObject): String? =
        enviarJson(target, payload, emptyMap()) { it.optString("reply").takeIf(String::isNotBlank) }

    private fun enviarJson(
        target: String,
        payload: JSONObject,
        headers: Map<String, String>,
        parser: (JSONObject) -> String?
    ): String? {
        val connection = (URL(target).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 10_000
            readTimeout = 45_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
            headers.forEach { (name, value) -> setRequestProperty(name, value) }
        }
        return try {
            connection.outputStream.bufferedWriter(Charsets.UTF_8).use { it.write(payload.toString()) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val responseText = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val message = runCatching {
                    JSONObject(responseText).optJSONObject("error")?.optString("message")
                }.getOrNull().orEmpty()
                throw IllegalStateException("Erro $code${if (message.isNotBlank()) ": $message" else ""}")
            }
            parser(JSONObject(responseText))
        } finally {
            connection.disconnect()
        }
    }

    private fun erroAmigavel(raw: String?): String? {
        val erro = raw?.trim().orEmpty()
        if (erro.isBlank()) return null
        return when {
            erro.contains("Erro 429") -> "A API está conectada, mas o limite de uso da chave foi atingido. Aguarde a cota liberar ou confira o plano/cota no Google AI Studio."
            erro.contains("Erro 401") || erro.contains("Erro 403") ||
                erro.contains("API key not valid", ignoreCase = true) ->
                "A chave da API foi recusada pelo Google. Gere ou confira a chave no Google AI Studio."
            erro.contains("Erro 404") -> "O modelo/endpoint não estava disponível para esta chave. A AIDA tentou modelos compatíveis e o modo normal automaticamente."
            erro.contains("Erro 400") -> "A API recebeu uma solicitação inválida. A AIDA tentou novamente sem o histórico."
            erro.contains("Unable to resolve host", ignoreCase = true) ||
                erro.contains("timeout", ignoreCase = true) ->
                "Não consegui alcançar a API agora. Confira a internet e tente novamente."
            else -> "A API respondeu com erro: ${erro.take(180)}"
        }
    }

    companion object {
        // Ordem de preferência. A lista real é filtrada dinamicamente por /v1beta/models.
        private val GEMINI_MODELS = listOf(
            "gemini-3.5-flash-lite",
            "gemini-3.1-flash-lite",
            "gemini-2.5-flash-lite",
            "gemini-3.6-flash",
            "gemini-3.5-flash",
            "gemini-2.5-flash"
        )
    }
}
